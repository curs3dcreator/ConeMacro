@echo off
cd /d "%~dp0"
python -c "import PIL" >nul 2>nul || python -m pip install pillow >nul 2>nul
where pyw >nul 2>nul && (start "" pyw -3 main.py & exit /b)
where pythonw >nul 2>nul && (start "" pythonw main.py & exit /b)
echo Python was not found. Install it from https://www.python.org/downloads/
echo and tick "Add python.exe to PATH" in the installer, then run this again.
pause
