"""Global start/stop hotkey (works while Roblox has focus). Windows only.

A hotkey is stored as text like "F5" or "Ctrl+Shift+S". We poll the key
state instead of registering a system hotkey, so the key still reaches the
game / other apps normally.
"""
import sys
import threading
import time

IS_WINDOWS = sys.platform == "win32"
if IS_WINDOWS:
    import ctypes

    _user32 = ctypes.windll.user32

DEFAULT_HOTKEY = "F5"

_NAMED = {
    "Space": 0x20, "Enter": 0x0D, "Tab": 0x09, "Esc": 0x1B,
    "Backspace": 0x08, "Insert": 0x2D, "Delete": 0x2E, "Home": 0x24,
    "End": 0x23, "PageUp": 0x21, "PageDown": 0x22,
    "Left": 0x25, "Up": 0x26, "Right": 0x27, "Down": 0x28,
    ";": 0xBA, "=": 0xBB, ",": 0xBC, "-": 0xBD, ".": 0xBE, "/": 0xBF,
    "`": 0xC0, "[": 0xDB, "\\": 0xDC, "]": 0xDD, "'": 0xDE,
}
for _i in range(1, 25):
    _NAMED[f"F{_i}"] = 0x70 + _i - 1
for _i in range(10):
    _NAMED[f"Num{_i}"] = 0x60 + _i
for _c in "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789":
    _NAMED[_c] = ord(_c)

_MOD_VK = {"Ctrl": 0x11, "Shift": 0x10, "Alt": 0x12}
_MOD_ORDER = ("Ctrl", "Alt", "Shift")

# Tk keysym -> our key name
_KEYSYM = {
    "space": "Space", "Return": "Enter", "KP_Enter": "Enter", "Tab": "Tab",
    "Escape": "Esc", "BackSpace": "Backspace", "Insert": "Insert",
    "Delete": "Delete", "Home": "Home", "End": "End", "Prior": "PageUp",
    "Next": "PageDown", "Left": "Left", "Up": "Up", "Right": "Right",
    "Down": "Down", "semicolon": ";", "equal": "=", "comma": ",",
    "minus": "-", "period": ".", "slash": "/", "grave": "`",
    "bracketleft": "[", "backslash": "\\", "bracketright": "]",
    "apostrophe": "'",
}
for _i in range(10):
    _KEYSYM[f"KP_{_i}"] = f"Num{_i}"

MODIFIER_KEYSYMS = {
    "Shift_L", "Shift_R", "Control_L", "Control_R", "Alt_L", "Alt_R",
    "Meta_L", "Meta_R", "Super_L", "Super_R", "Caps_Lock", "Num_Lock",
    "ISO_Level3_Shift",
}


def parse(spec):
    """'Ctrl+F5' -> (frozenset({'Ctrl'}), 0x74), or None if invalid."""
    if not spec or not isinstance(spec, str):
        return None

    parts = [p.strip() for p in spec.split("+") if p.strip()]

    if not parts:
        return None

    key = parts[-1]
    mods = set()

    for m in parts[:-1]:
        name = m.capitalize()
        if name not in _MOD_VK:
            return None
        mods.add(name)

    vk = _NAMED.get(key if key in _NAMED else key.upper())

    if vk is None:
        return None

    return frozenset(mods), vk


def format_spec(mods, key):
    return "+".join([m for m in _MOD_ORDER if m in mods] + [key])


def spec_from_event(event):
    """Build a hotkey string from a Tk <KeyPress> event, or None if the
    key is only a modifier / unsupported."""
    keysym = event.keysym

    if keysym in MODIFIER_KEYSYMS:
        return None

    if keysym in _KEYSYM:
        key = _KEYSYM[keysym]
    elif len(keysym) == 1:
        key = keysym.upper()
    elif keysym.upper() in _NAMED:  # F1..F24
        key = keysym.upper()
    else:
        return None

    state = event.state
    mods = set()

    if state & 0x4:
        mods.add("Ctrl")
    if state & 0x1:
        mods.add("Shift")
    if state & (0x20000 | 0x8):
        mods.add("Alt")

    spec = format_spec(mods, key)
    return spec if parse(spec) else None


def is_safe(spec):
    """Reject plain typing keys (A, 5, Space...) with no modifier, since the
    hotkey is global and would fire while you type."""
    parsed = parse(spec)

    if not parsed:
        return False

    mods, vk = parsed
    key = spec.split("+")[-1]

    if mods:
        return True

    return (
        key.startswith("F") and key[1:].isdigit()
        or key in ("Insert", "Delete", "Home", "End", "PageUp", "PageDown")
        or key.startswith("Num")
    )


def _down(vk):
    return bool(_user32.GetAsyncKeyState(vk) & 0x8000)


class HotkeyWatcher(threading.Thread):
    """Calls callback() each time the configured hotkey is pressed."""

    def __init__(self, spec_fn, callback, paused_fn=lambda: False):
        super().__init__(daemon=True, name="cone-hotkey")
        self.spec_fn, self.callback, self.paused_fn = spec_fn, callback, paused_fn
        self._stop_evt = threading.Event()

    def stop(self):
        self._stop_evt.set()

    def run(self):
        if not IS_WINDOWS:
            return

        was_down = False
        last_fire = 0.0

        while not self._stop_evt.wait(0.025):
            parsed = parse(self.spec_fn())

            if not parsed or self.paused_fn():
                was_down = True  # don't fire the instant it becomes active
                continue

            mods, vk = parsed
            pressed = _down(vk) and all(
                _down(_MOD_VK[m]) == (m in mods) for m in _MOD_VK
            )

            if pressed and not was_down and time.time() - last_fire > 0.3:
                last_fire = time.time()
                self.callback()

            was_down = pressed
