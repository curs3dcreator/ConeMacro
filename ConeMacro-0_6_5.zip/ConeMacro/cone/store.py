
"""Settings + biome history, saved as plain files in your local app data."""

import json
import os
import time
from pathlib import Path

from . import APP_NAME

DEFAULTS = {
    "webhook_url": "",
    "account_name": "",
    "private_server_link": "",
    "accounts": [],
    "instance_accounts": {},
    "multi_macro_enabled": False,
    "mention": "",

    "ping_tiers": {
        "rare": True,
        "special": True,
        "dev": True,
        "event": False,
        "common": False,
        "unknown": True,
    },

    "webhook_tiers": {
        "rare": True,
        "special": True,
        "dev": True,
        "event": True,
        "common": False,
        "unknown": True,
    },

    "sound_enabled": True,

    "sound_tiers": {
        "rare": True,
        "special": True,
        "dev": True,
        "event": True,
        "common": False,
        "unknown": True,
    },

    # Extra Discord destinations. Each: {id, name, url, enabled, ping,
    # tiers: {tier: bool}}. The main webhook above keeps its own tier rules.
    "webhook_extra": [],

    # Warn when Roblox log activity stops for this many minutes (0 = off).
    "health_warning_minutes": 15,

    # Custom rare biome alert sound.
    # Empty means use the original built-in beep pattern.
    "rare_custom_sound": "",

    # Global start/stop hotkey, e.g. "F5" or "Ctrl+Shift+S". Empty = off.
    "hotkey": "F5",

    "antiafk_enabled": False,
    "antiafk_minutes": 10,
    "log_dir": "",
    "session_summary": True,

    # Appearance settings.
    "appearance_theme": "Midnight",
    "appearance_accent": "",
    "appearance_background": "",
    "appearance_mascot": "",
    "appearance_rounded": True,
    "appearance_animations": True,
}


def data_dir() -> Path:
    base = os.getenv("LOCALAPPDATA") or os.path.expanduser("~/.local/share")
    p = Path(base) / APP_NAME
    p.mkdir(parents=True, exist_ok=True)
    return p


class Settings:
    def __init__(self, folder: Path = None):
        self.path = (folder or data_dir()) / "settings.json"
        self.data = json.loads(json.dumps(DEFAULTS))
        saved = {}

        try:
            saved = json.loads(self.path.read_text("utf-8"))

            if not isinstance(saved, dict):
                saved = {}

            for k, v in saved.items():
                if isinstance(v, dict) and isinstance(self.data.get(k), dict):
                    self.data[k].update(v)
                elif k in self.data:
                    self.data[k] = v

        except (OSError, ValueError):
            pass

        # Migrate the original single-account fields.
        if "accounts" not in saved and self.data.get("account_name"):
            import uuid

            self.data["accounts"] = [{
                "id": uuid.uuid4().hex[:10],
                "name": self.data.get("account_name", "").strip(),
                "private_server_link": self.data.get(
                    "private_server_link", ""
                ).strip(),
            }]

        if not isinstance(self.data.get("accounts"), list):
            self.data["accounts"] = []

        if not isinstance(self.data.get("instance_accounts"), dict):
            self.data["instance_accounts"] = []

        if not isinstance(self.data.get("rare_custom_sound"), str):
            self.data["rare_custom_sound"] = ""

    def save(self):
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(
            json.dumps(self.data, indent=2),
            "utf-8"
        )
        tmp.replace(self.path)

    def __getitem__(self, k):
        return self.data[k]

    def get(self, k, default=None):
        return self.data.get(k, default)

    def __setitem__(self, k, v):
        self.data[k] = v


class History:
    """Append-only jsonl log of every biome seen, plus counters."""

    def __init__(self, folder: Path = None):
        self.path = (folder or data_dir()) / "history.jsonl"
        self.rows = []

        try:
            for line in self.path.read_text("utf-8").splitlines():
                try:
                    self.rows.append(json.loads(line))
                except ValueError:
                    pass
        except OSError:
            pass

        self.session_start = time.time()
        self.session_rows = []
        self.state_path = (folder or data_dir()) / "state.json"
        self.since_rare = 0
        self.last_rare_at = None
        self._load_state()

    def _load_state(self):
        """Restore the 'since last rare' counter from the previous run."""
        try:
            state = json.loads(self.state_path.read_text("utf-8"))
            self.since_rare = max(0, int(state.get("since_rare", 0)))
            last = state.get("last_rare_at")
            self.last_rare_at = float(last) if last else None
            return
        except (OSError, ValueError, TypeError, AttributeError):
            pass

        # No saved state yet (first boot after updating): rebuild it
        # from the existing history log.
        for r in self.rows:
            tier = r.get("tier")

            if tier in ("rare", "special"):
                self.since_rare = 0
                self.last_rare_at = r.get("t")
            elif tier != "none":
                self.since_rare += 1

    def save_state(self):
        try:
            tmp = self.state_path.with_suffix(".tmp")
            tmp.write_text(
                json.dumps({
                    "since_rare": self.since_rare,
                    "last_rare_at": self.last_rare_at,
                }),
                "utf-8",
            )
            tmp.replace(self.state_path)
        except OSError:
            pass

    def add(self, instance, biome):
        row = {
            "t": time.time(),
            "inst": instance,
            "key": biome.key,
            "name": biome.name,
            "tier": biome.tier,
        }

        self.rows.append(row)
        self.session_rows.append(row)

        if biome.tier in ("rare", "special"):
            self.since_rare = 0
            self.last_rare_at = row["t"]
        elif biome.tier != "none":
            self.since_rare += 1

        self.save_state()

        try:
            with open(self.path, "a", encoding="utf-8") as fh:
                fh.write(json.dumps(row) + "\n")
        except OSError:
            pass

        return row

    @staticmethod
    def count(rows):
        out = {}

        for r in rows:
            if r["tier"] == "none":
                continue

            out[r["key"]] = out.get(r["key"], 0) + 1

        return out

    def lifetime_counts(self):
        return self.count(self.rows)

    def session_counts(self):
        return self.count(self.session_rows)
