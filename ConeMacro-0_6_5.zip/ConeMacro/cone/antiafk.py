"""Anti-AFK: every N minutes, tap Space in each Roblox window.

Roblox only listens to the focused window, so this briefly brings each
window forward, taps Space, then puts your previous window back. Windows only.
"""
import sys
import threading
import time

IS_WINDOWS = sys.platform == "win32"
if IS_WINDOWS:
    import ctypes
    from ctypes import wintypes

    user32 = ctypes.windll.user32
    kernel32 = ctypes.windll.kernel32

    user32.GetForegroundWindow.restype = wintypes.HWND
    user32.SetForegroundWindow.argtypes = [wintypes.HWND]
    user32.BringWindowToTop.argtypes = [wintypes.HWND]
    user32.IsIconic.argtypes = [wintypes.HWND]
    user32.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
    user32.GetWindowThreadProcessId.argtypes = [
        wintypes.HWND, ctypes.POINTER(wintypes.DWORD)
    ]
    user32.AttachThreadInput.argtypes = [
        wintypes.DWORD, wintypes.DWORD, wintypes.BOOL
    ]

VK_SPACE, VK_MENU, KEYUP = 0x20, 0x12, 0x0002
SCAN_SPACE = 0x39
SW_RESTORE, SW_SHOWMINNOACTIVE = 9, 7


def roblox_windows():
    if not IS_WINDOWS:
        return []
    found = []

    @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    def cb(hwnd, _):
        if user32.IsWindowVisible(hwnd):
            buf = ctypes.create_unicode_buffer(64)
            user32.GetWindowTextW(hwnd, buf, 64)
            if buf.value == "Roblox":
                found.append(hwnd)
        return True

    user32.EnumWindows(cb, 0)
    return found


def _thread_of(hwnd):
    return user32.GetWindowThreadProcessId(hwnd, None) if hwnd else 0


def _focus(hwnd, timeout=1.5):
    """Bring hwnd to the front WITHOUT changing its size/fullscreen state.

    The old version called ShowWindow(SW_RESTORE) on every window, which
    un-maximizes / un-fullscreens a window that is already on screen
    (both Roblox and the window we returned to). Now we only restore a
    window if it is actually minimized.
    """
    if not hwnd:
        return False

    if user32.GetForegroundWindow() == hwnd:
        return True

    if user32.IsIconic(hwnd):
        user32.ShowWindow(hwnd, SW_RESTORE)

    me = kernel32.GetCurrentThreadId()
    threads = {_thread_of(user32.GetForegroundWindow()), _thread_of(hwnd)}
    attached = [
        t for t in threads
        if t and t != me and user32.AttachThreadInput(me, t, True)
    ]

    try:
        user32.BringWindowToTop(hwnd)
        user32.SetForegroundWindow(hwnd)
    finally:
        for t in attached:
            user32.AttachThreadInput(me, t, False)

    if user32.GetForegroundWindow() != hwnd:
        # Fallback: a tapped ALT lets SetForegroundWindow succeed.
        user32.keybd_event(VK_MENU, 0, 0, 0)
        user32.keybd_event(VK_MENU, 0, KEYUP, 0)
        user32.SetForegroundWindow(hwnd)

    end = time.time() + timeout

    while time.time() < end:
        if user32.GetForegroundWindow() == hwnd:
            time.sleep(0.25)  # let a fullscreen game finish taking focus
            return True

        time.sleep(0.05)

    return False


def _tap_space():
    user32.keybd_event(VK_SPACE, SCAN_SPACE, 0, 0)
    time.sleep(0.08)
    user32.keybd_event(VK_SPACE, SCAN_SPACE, KEYUP, 0)


def pulse() -> int:
    """Tap Space in every Roblox window. Returns how many were poked."""
    if not IS_WINDOWS:
        return 0

    wins = roblox_windows()

    if not wins:
        return 0

    previous = user32.GetForegroundWindow()
    poked = 0

    for hwnd in wins:
        was_minimized = bool(user32.IsIconic(hwnd))

        if _focus(hwnd):
            _tap_space()
            poked += 1
            time.sleep(0.2)

        # If Roblox started minimized, put it back that way.
        if was_minimized and hwnd != previous:
            user32.ShowWindow(hwnd, SW_SHOWMINNOACTIVE)

    if previous and previous not in wins:
        _focus(previous)

    return poked


class AntiAfk(threading.Thread):
    def __init__(self, minutes_fn, on_pulse=None):
        super().__init__(daemon=True, name="cone-antiafk")
        self.minutes_fn, self.on_pulse = minutes_fn, on_pulse
        self._stop_evt = threading.Event()

    def stop(self):
        self._stop_evt.set()

    def run(self):
        while True:
            wait = max(1.0, float(self.minutes_fn())) * 60
            if self._stop_evt.wait(wait):
                return
            n = pulse()
            if self.on_pulse:
                self.on_pulse(n)
