"""Roblox log watcher for Sol's RNG Rich Presence biome updates.

Roblox/Bloxstrap writes SetRichPresence payloads to its client log.  This
parser deliberately accepts both the nested largeImage.hoverText format and
older/alternate hoverText layouts used by different launchers.
"""
import glob
import json
import os
import re
import threading
import time

MARKER = re.compile(r"\[BloxstrapRPC\]", re.IGNORECASE)
HOVER = re.compile(r'"hoverText"\s*:\s*"((?:\\.|[^"\\])*)"', re.IGNORECASE)
TAIL_BYTES = 512 * 1024
FRESH_SECONDS = 30 * 60

# Roblox client logs commonly reveal the in-game username in PlayerGui paths.
# This is the same lightweight identification strategy used by the reference
# macro project; it avoids cookies, credentials, or account-session access.
_TUTORIAL_USER = re.compile(
    r'Players\.([^\.\'"\s]+)\.PlayerGui:WaitForChild\(\s*["\']TutorialCursor["\']',
    re.IGNORECASE,
)
_PLAYERS_USER = re.compile(r"Players\.([A-Za-z0-9_]{3,20})\.PlayerGui", re.IGNORECASE)


def _decode_hover(value):
    try:
        return json.loads('"' + value + '"').strip()
    except (ValueError, TypeError):
        return value.replace('\\"', '"').strip()


def parse_line(line: str):
    """Return biome hover text from a Rich Presence log line, or None."""
    if not line or not MARKER.search(line):
        return None

    # Parse the JSON payload first; this handles escaped characters correctly.
    marker = MARKER.search(line)
    payload = line[marker.end():].strip()
    start = payload.find('{')
    if start >= 0:
        try:
            obj, _ = json.JSONDecoder().raw_decode(payload[start:])
            data = obj.get("data", {}) if isinstance(obj, dict) else {}
            if isinstance(data, dict):
                large = data.get("largeImage", {})
                if isinstance(large, dict):
                    value = large.get("hoverText")
                    if isinstance(value, str) and value.strip():
                        return value.strip()
                # Some RPC variants place hoverText elsewhere in data.
                value = data.get("hoverText")
                if isinstance(value, str) and value.strip():
                    return value.strip()
        except (ValueError, TypeError):
            pass

    # Fallback for payloads with extra log text or non-standard JSON layout.
    match = HOVER.search(line)
    return _decode_hover(match.group(1)) if match else None


def username_of_log(path: str) -> str:
    """Best-effort Roblox username extracted from a client log, or empty."""
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as fh:
            head = fh.read(200_000)
    except OSError:
        return ""
    match = _TUTORIAL_USER.search(head) or _PLAYERS_USER.search(head)
    return match.group(1).strip().lower() if match else ""


def log_dirs(custom: str = ""):
    if custom:
        return [custom]
    local = os.getenv("LOCALAPPDATA") or ""
    dirs = [os.path.join(local, "Roblox", "logs")]
    dirs += glob.glob(os.path.join(local, "Packages", "ROBLOXCORPORATION.ROBLOX_*", "LocalState", "logs"))
    return [d for d in dirs if os.path.isdir(d)]


class _Tracked:
    def __init__(self, path, label, username=""):
        self.path, self.label, self.username = path, label, username
        self.pos = 0
        self.buf = b""
        self.biome = None
        self.identity = None
        self.last_growth = time.time()


class LogWatcher(threading.Thread):
    """callback(label, raw_biome, silent) is called on biome changes."""

    def __init__(self, callback, custom_dir_fn=lambda: "", poll=0.5,
                 multi_macro_fn=lambda: False, accounts_fn=lambda: []):
        super().__init__(daemon=True, name="cone-logwatch")
        self.callback, self.custom_dir_fn, self.poll = callback, custom_dir_fn, poll
        self.multi_macro_fn = multi_macro_fn
        self.accounts_fn = accounts_fn
        self._stop_evt = threading.Event()
        self._files = {}
        self._n = 0

    def stop(self):
        self._stop_evt.set()

    def run(self):
        last_scan = 0.0
        while not self._stop_evt.is_set():
            now = time.time()
            if now - last_scan > 2:
                self._scan(now)
                last_scan = now
            for tracked in list(self._files.values()):
                self._read(tracked)
            self._stop_evt.wait(self.poll)

    def _scan(self, now):
        seen = set()
        candidates = []
        for directory in log_dirs(self.custom_dir_fn()):
            candidates.extend(glob.glob(os.path.join(directory, "*.log")))
        # Filter stale logs BEFORE choosing the single instance. Previously the
        # first alphabetic filename was selected and only then checked for age;
        # if that file was stale, a perfectly active Roblox log could be ignored.
        active = []
        for path in sorted(set(candidates)):
            try:
                modified = os.path.getmtime(path)
            except OSError:
                continue
            if now - modified <= FRESH_SECONDS:
                active.append((path, modified))

        if self.multi_macro_fn():
            selected = [path for path, _ in active]
        else:
            # In single mode follow the currently active client, represented by
            # the most recently updated Roblox log, rather than an arbitrary file.
            active.sort(key=lambda item: (item[1], item[0]), reverse=True)
            selected = [active[0][0]] if active else []

        for path in selected:
            seen.add(path)
            if path not in self._files:
                self._attach(path)
        for path in list(self._files):
            if path not in seen:
                del self._files[path]

    def _attach(self, path):
        try:
            stat = os.stat(path)
            size = stat.st_size
            identity = (getattr(stat, "st_ino", 0), getattr(stat, "st_mtime_ns", 0))
            with open(path, "rb") as fh:
                fh.seek(max(0, size - TAIL_BYTES))
                chunk = fh.read()
        except OSError:
            return

        self._n += 1
        username = username_of_log(path)
        accounts = self.accounts_fn() or []
        matched = next((a for a in accounts
                        if username and str(a.get("name", "")).strip().casefold() == username.casefold()), None)
        # Prefer the actual account username when it can be read from the log.
        # Otherwise keep a neutral instance label so the user can route it in
        # Account -> Instance Routing.
        base_label = (matched or {}).get("name") or username or f"Roblox #{self._n}"
        existing = {item.label.casefold() for item in self._files.values()}
        label = base_label
        suffix = 2
        while label.casefold() in existing:
            label = f"{base_label} ({suffix})"
            suffix += 1
        tracked = _Tracked(path, label, username)
        tracked.pos = size
        tracked.identity = identity
        # Seed current state from the tail, without counting an old biome as
        # a fresh spawn when the user presses Start.
        parts = chunk.split(b"\n")
        tracked.buf = parts.pop()  # preserve a trailing partial RPC line
        for line in parts:
            raw = parse_line(line.decode("utf-8", "ignore").rstrip("\r"))
            if raw:
                tracked.biome = raw
        self._files[path] = tracked
        if tracked.biome:
            self.callback(tracked.label, tracked.biome, True)

    def _read(self, tracked):
        try:
            stat = os.stat(tracked.path)
            size = stat.st_size
            identity = (getattr(stat, "st_ino", 0), getattr(stat, "st_mtime_ns", 0))
            # A replaced/truncated log starts a new stream. Re-read from the
            # beginning so the first detected update is not skipped.
            if size < tracked.pos or (tracked.identity and identity[0] and tracked.identity[0] != identity[0]):
                tracked.pos, tracked.buf, tracked.biome = 0, b"", None
            tracked.identity = identity
            if size == tracked.pos:
                return
            with open(tracked.path, "rb") as fh:
                fh.seek(tracked.pos)
                data = fh.read()
            tracked.pos += len(data)
            tracked.last_growth = time.time()
        except OSError:
            return

        tracked.buf += data
        lines = tracked.buf.split(b"\n")
        tracked.buf = lines.pop()  # keep a partial final line for the next poll
        for line in lines:
            raw = parse_line(line.decode("utf-8", "ignore").rstrip("\r"))
            if raw and raw != tracked.biome:
                tracked.biome = raw
                self.callback(tracked.label, raw, False)
