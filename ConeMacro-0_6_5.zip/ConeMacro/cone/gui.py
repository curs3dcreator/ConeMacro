"""The ConeMacro window (tkinter - ships with Python, nothing to install)."""
import math
import os
import random
import sys
import time
import uuid
import tkinter as tk
import tkinter.font as tkfont
from tkinter import filedialog, messagebox, ttk, colorchooser

from . import APP_NAME, APP_VERSION, hotkey, sound, webhook
from .biomes import ALL, BY_KEY, TIERS
from .cutscene import LOVE_ACCOUNTS, LoveCutscene
from .engine import Engine
from .store import History, Settings

try:  # Pillow is optional; it gives smooth image scaling.
    from PIL import Image, ImageTk
except Exception:  # pragma: no cover
    Image = ImageTk = None


BG, PANEL, PANEL2 = "#100d0b", "#191410", "#241c15"
ORANGE, ORANGE_D = "#f5ad42", "#d88a25"
TEXT, MUTED, GOOD, BAD = "#f2eee8", "#a69a8b", "#65d6a3", "#ff7272"

THEMES = {
    "Midnight": {
        "BG": "#100d0b", "PANEL": "#191410", "PANEL2": "#241c15",
        "ORANGE": "#f5ad42", "ORANGE_D": "#d88a25",
        "TEXT": "#f2eee8", "MUTED": "#a69a8b",
        "GOOD": "#65d6a3", "BAD": "#ff7272",
    },
    "Ocean": {
        "BG": "#0c1824", "PANEL": "#14283a", "PANEL2": "#1d394e",
        "ORANGE": "#42c8e8", "ORANGE_D": "#239bbd",
        "TEXT": "#e5f7ff", "MUTED": "#91b5c8",
        "GOOD": "#65d6a3", "BAD": "#ff7272",
    },
    "Crimson": {
        "BG": "#1c1015", "PANEL": "#2b1921", "PANEL2": "#40232e",
        "ORANGE": "#ff647c", "ORANGE_D": "#d94360",
        "TEXT": "#fff0f3", "MUTED": "#c09ba5",
        "GOOD": "#65d6a3", "BAD": "#ff7272",
    },
    "Purple": {
        "BG": "#171222", "PANEL": "#241b35", "PANEL2": "#33264a",
        "ORANGE": "#bd91ff", "ORANGE_D": "#9667dc",
        "TEXT": "#f4edff", "MUTED": "#ac9cbd",
        "GOOD": "#65d6a3", "BAD": "#ff7272",
    },
    "Light": {
        "BG": "#e9edf3", "PANEL": "#ffffff", "PANEL2": "#dce3ec",
        "ORANGE": "#df792c", "ORANGE_D": "#bd5d1b",
        "TEXT": "#202b3a", "MUTED": "#667589",
        "GOOD": "#208b62", "BAD": "#d94444",
    },
}

TIER_COLOR = {
    "rare": "#ff4fa0",
    "special": "#b57cff",
    "dev": "#ff5c5c",
    "event": "#ffc23d",
    "common": "#c9b79f",
    "unknown": "#8ab4ff",
    "none": MUTED,
}

IDLE_LINES = [
    "Rolling along~",
    "Cones up!",
    "Any glitched yet?",
    "I'm watching the log.",
    "Stay orange.",
    "Snack break? Nope, keep rolling.",
    "Luck is a state of mind.",
]

REACT = {
    "rare": ["WOAH!! {b}!!!", "{b}?! No way!", "RARE!! {b}!! Go go go!"],
    "special": ["{b}!? That's huge!", "Whoa, {b}!"],
    "dev": ["A dev biome?! {b}!!", "{b}?! A developer is here!"],
    "event": ["{b} is here!", "Event time: {b}!"],
    "common": ["{b}.", "Ooh, {b}.", "{b} again~"],
    "unknown": ["Never seen {b} before!"],
}


class RoundedButton(tk.Canvas):
    """Lightweight, dependency-free rounded button drawn on a Canvas."""
    def __init__(self, parent, text, command, primary=False, width=None,
                 height=38, anchor="center", **kwargs):
        self._text = text
        self._command = command
        self._primary = primary
        self._anchor = anchor
        self._enabled = True
        self._base_bg = ORANGE if primary else PANEL2
        self._base_fg = "#21170d" if primary else TEXT
        self._hover_bg = lighten(self._base_bg, 0.13)
        font = ("Segoe UI", 9, "bold")
        measured = tkfont.Font(family=font[0], size=font[1], weight=font[2]).measure(text)
        self._width = width or max(76, measured + 34)
        self._height = height
        super().__init__(parent, width=self._width, height=height,
                         bg=parent.cget("bg"), highlightthickness=0, bd=0,
                         cursor="hand2")
        self._font = font
        self._draw()
        self.bind("<Enter>", self._enter)
        self.bind("<Leave>", self._leave)
        self.bind("<Button-1>", self._click)
        self.bind("<ButtonRelease-1>", self._release)

    def _round_rect(self, x1, y1, x2, y2, r, **kw):
        points = [x1+r,y1, x2-r,y1, x2,y1, x2,y1+r,
                  x2,y2-r, x2,y2, x2-r,y2, x1+r,y2,
                  x1,y2, x1,y2-r, x1,y1+r, x1,y1]
        return self.create_polygon(points, smooth=True, splinesteps=20, **kw)

    def _draw(self, bg=None):
        self.delete("all")
        fill = bg or self._base_bg
        self._round_rect(1, 1, self._width-1, self._height-1, 12,
                         fill=fill, outline="")
        x = 14 if self._anchor == "w" else self._width/2
        self.create_text(x, self._height/2, text=self._text,
                         fill=self._base_fg, font=self._font,
                         anchor="w" if self._anchor == "w" else "center")

    def _enter(self, _event=None):
        if self._enabled:
            self._draw(self._hover_bg)

    def _leave(self, _event=None):
        self._draw()

    def _click(self, _event=None):
        if self._enabled:
            self._draw(self._hover_bg)

    def _release(self, event=None):
        self._draw(self._hover_bg if self._enabled else self._base_bg)
        if self._enabled and event and 0 <= event.x <= self._width and 0 <= event.y <= self._height:
            self._command()

    def configure(self, cnf=None, **kw):
        if isinstance(cnf, dict):
            kw.update(cnf)
        if "text" in kw:
            self._text = kw.pop("text")
        if "bg" in kw:
            self._base_bg = kw.pop("bg")
            self._hover_bg = lighten(self._base_bg, 0.13)
        if "fg" in kw:
            self._base_fg = kw.pop("fg")
        if "state" in kw:
            self._enabled = str(kw.pop("state")) != "disabled"
            self.configure(cursor="hand2" if self._enabled else "arrow")
        if kw:
            return super().configure(**kw)
        self._draw()

    config = configure



def asset(name):
    base = getattr(
        sys,
        "_MEIPASS",
        os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    )
    return os.path.join(base, "assets", name)


def fmt_clock(sec):
    sec = int(max(0, sec))
    return (
        f"{sec // 3600:d}:{sec % 3600 // 60:02d}:{sec % 60:02d}"
        if sec >= 3600
        else f"{sec // 60:02d}:{sec % 60:02d}"
    )


def fit_image(path, max_w, max_h):
    """Load an image scaled to fit inside max_w x max_h (keeps aspect)."""
    max_w, max_h = max(1, int(max_w)), max(1, int(max_h))

    if Image is not None:
        img = Image.open(path)
        img.load()
        img = img.convert("RGBA")
        scale = min(max_w / img.width, max_h / img.height)

        if abs(scale - 1) > 0.01:
            img = img.resize(
                (
                    max(1, round(img.width * scale)),
                    max(1, round(img.height * scale)),
                ),
                Image.LANCZOS,
            )

        return ImageTk.PhotoImage(img)

    # No Pillow: best effort with whole-number zoom / subsample.
    photo = tk.PhotoImage(file=path)
    w, h = photo.width(), photo.height()

    if w > max_w or h > max_h:
        f = max(math.ceil(w / max_w), math.ceil(h / max_h))
        photo = photo.subsample(f, f)
    else:
        f = min(max_w // w, max_h // h)

        if f >= 2:
            photo = photo.zoom(f, f)

    return photo


def lighten(color, amount=0.1):
    color = color.lstrip("#")

    try:
        r, g, b = (int(color[i:i + 2], 16) for i in (0, 2, 4))
    except ValueError:
        return "#" + color

    f = lambda v: min(255, int(v + (255 - v) * amount))
    return f"#{f(r):02x}{f(g):02x}{f(b):02x}"


IMAGE_TYPES = (
    [("Images", "*.png *.gif *.jpg *.jpeg *.bmp *.webp"),
     ("All files", "*.*")]
    if Image is not None
    else [("PNG and GIF images", "*.png *.gif")]
)

MASCOT_BOX = (230, 320)


class App:
    def __init__(self, root):
        self.root = root
        self.settings = Settings()

        self._apply_saved_theme()

        self.history = History()
        self.engine = Engine(self.settings, self.history)

        self.bubble_until = 0.0
        self.last_idle = 0.0

        self.wallpaper_image = None
        self.wallpaper_item = None
        self._mascot = None

        # Scrollable page references.
        self._scroll_canvases = {}
        self._active_scroll_canvas = None
        self._mousewheel_bound = False

        root.title(f"{APP_NAME} {APP_VERSION}")
        root.geometry("1220x820")
        root.minsize(980, 620)
        self._current_page = None
        root.configure(bg=BG)

        try:
            if sys.platform == "win32":
                root.iconbitmap(asset("icon.ico"))
            else:
                self._icon = tk.PhotoImage(file=asset("icon.png"))
                root.iconphoto(True, self._icon)
        except Exception:
            pass

        self._style()
        self._setup_wallpaper()
        self._header()

        self._pages = {}
        self._body = tk.Frame(root, bg=BG)

        self._nav()

        self._body.pack(
            side="right",
            fill="both",
            expand=True,
            padx=(0, 18),
            pady=(0, 18)
        )

        self._build_dashboard()
        self._build_history()
        self._build_stats()
        self._build_account()
        self._build_settings()
        self._build_appearance()

        self.show("Dashboard")
        self._load_history_rows()
        self.refresh_stats()

        # Global start/stop hotkey.
        self._hotkey_capturing = False
        self._hotkey_bind = None
        self._refresh_hotkey_ui()

        self._hotkeys = hotkey.HotkeyWatcher(
            lambda: self.settings.get("hotkey", ""),
            lambda: self.engine.events.put(("hotkey",)),
            lambda: self._hotkey_capturing
        )
        self._hotkeys.start()

        if not hotkey.IS_WINDOWS:
            # No global hook off Windows: work while the window has focus.
            root.bind_all("<KeyPress>", self._tk_hotkey, add="+")

        root.protocol("WM_DELETE_WINDOW", self.close)
        root.after(200, self._poll)
        root.after(50, self._animate)
        root.after(1000, self._tick)

    # ---------- appearance helpers -----------------------------------------

    def _apply_saved_theme(self):
        global BG, PANEL, PANEL2
        global ORANGE, ORANGE_D
        global TEXT, MUTED, GOOD, BAD

        theme_name = self.settings.get(
            "appearance_theme",
            "Midnight"
        )

        theme = THEMES.get(
            theme_name,
            THEMES["Midnight"]
        )

        BG = theme["BG"]
        PANEL = theme["PANEL"]
        PANEL2 = theme["PANEL2"]
        ORANGE = theme["ORANGE"]
        ORANGE_D = theme["ORANGE_D"]
        TEXT = theme["TEXT"]
        MUTED = theme["MUTED"]
        GOOD = theme["GOOD"]
        BAD = theme["BAD"]

        accent = self.settings.get("appearance_accent", "")

        if accent:
            try:
                ORANGE = accent
                ORANGE_D = self._darken_color(accent)
            except Exception:
                pass

    @staticmethod
    def _darken_color(color):
        color = color.lstrip("#")

        if len(color) != 6:
            raise ValueError("Invalid color")

        r = max(0, int(color[0:2], 16) - 35)
        g = max(0, int(color[2:4], 16) - 35)
        b = max(0, int(color[4:6], 16) - 35)

        return f"#{r:02x}{g:02x}{b:02x}"

    def _setup_wallpaper(self):
        self.wallpaper_canvas = tk.Canvas(
            self.root,
            highlightthickness=0,
            bd=0,
            bg=BG
        )

        self.wallpaper_canvas.place(
            x=0,
            y=0,
            relwidth=1,
            relheight=1
        )

        self.root.tk.call(
            "lower",
            self.wallpaper_canvas._w
        )

        self._wp_src = None
        self._wp_job = None
        self._wp_rendered = None

        # Re-scale the background whenever the window size changes.
        self.wallpaper_canvas.bind(
            "<Configure>",
            self._schedule_wallpaper
        )

        path = self.settings.get(
            "appearance_background",
            ""
        )

        if path and os.path.isfile(path):
            self._load_wallpaper(path, show_error=False)

    def _schedule_wallpaper(self, _event=None):
        if self._wp_src is None:
            return

        if self._wp_job is not None:
            self.root.after_cancel(self._wp_job)

        self._wp_job = self.root.after(120, self._render_wallpaper)

    def _render_wallpaper(self):
        self._wp_job = None
        src = self._wp_src

        if src is None:
            return

        w = max(1, self.wallpaper_canvas.winfo_width())
        h = max(1, self.wallpaper_canvas.winfo_height())

        if self._wp_rendered == (w, h) and self.wallpaper_item:
            return

        try:
            if Image is not None:
                # "Cover" fit: fill the window, centre-crop the overflow.
                scale = max(w / src.width, h / src.height)
                nw = max(w, math.ceil(src.width * scale))
                nh = max(h, math.ceil(src.height * scale))
                img = src.resize((nw, nh), Image.LANCZOS)
                left, top = (nw - w) // 2, (nh - h) // 2
                img = img.crop((left, top, left + w, top + h))
                photo = ImageTk.PhotoImage(img)
            else:
                photo = src
                sw, sh = photo.width(), photo.height()

                if sw < w or sh < h:
                    f = max(math.ceil(w / sw), math.ceil(h / sh))
                    photo = photo.zoom(f, f)
                else:
                    f = max(1, min(sw // w, sh // h))

                    if f > 1:
                        photo = photo.subsample(f, f)
        except Exception:
            return

        self.wallpaper_image = photo

        if self.wallpaper_item is None:
            self.wallpaper_item = self.wallpaper_canvas.create_image(
                w // 2,
                h // 2,
                image=photo,
                anchor="center"
            )
        else:
            self.wallpaper_canvas.itemconfigure(
                self.wallpaper_item,
                image=photo
            )
            self.wallpaper_canvas.coords(
                self.wallpaper_item,
                w // 2,
                h // 2
            )

        self._wp_rendered = (w, h)

        self.root.tk.call(
            "lower",
            self.wallpaper_canvas._w
        )

    def _load_wallpaper(self, path, show_error=True):
        try:
            if Image is not None:
                src = Image.open(path)
                src.load()
                src = src.convert("RGB")

                # Keep the working copy reasonably small.
                if max(src.size) > 2560:
                    k = 2560 / max(src.size)
                    src = src.resize(
                        (round(src.width * k), round(src.height * k)),
                        Image.LANCZOS
                    )
            else:
                src = tk.PhotoImage(file=path)

            self._wp_src = src
            self._wp_rendered = None
            self._render_wallpaper()

            return True

        except Exception as exc:
            if show_error:
                messagebox.showerror(
                    APP_NAME,
                    f"Couldn't load that background image:\n{exc}"
                )

            return False

    def choose_background(self):
        path = filedialog.askopenfilename(
            title="Choose a background image",
            filetypes=IMAGE_TYPES
        )

        if not path:
            return

        if self._load_wallpaper(path):
            self.settings["appearance_background"] = path
            self.settings.save()
            self.notice("Background image saved and scaled to fit.")

    def remove_background(self):
        self.settings["appearance_background"] = ""
        self.settings.save()

        if self.wallpaper_item is not None:
            self.wallpaper_canvas.delete(
                self.wallpaper_item
            )
            self.wallpaper_item = None

        self._wp_src = None
        self.wallpaper_image = None
        self.notice("Background image removed.")

    def _set_mascot(self, path):
        image = fit_image(path, *MASCOT_BOX)

        self._mascot = image

        self.canvas.itemconfigure(
            self.mascot_item,
            image=self._mascot
        )

        self.canvas.coords(
            self.mascot_item,
            125,
            410
        )

    def choose_mascot(self):
        path = filedialog.askopenfilename(
            title="Choose your dashboard mascot",
            filetypes=IMAGE_TYPES
        )

        if not path:
            return

        try:
            self._set_mascot(path)

            self.settings["appearance_mascot"] = path
            self.settings.save()

            self.notice("Dashboard mascot updated and scaled to fit!")

        except Exception as exc:
            messagebox.showerror(
                APP_NAME,
                f"Couldn't load that mascot image:\n{exc}"
            )

    def reset_mascot(self):
        try:
            self._set_mascot(asset("mascot.png"))

            self.settings["appearance_mascot"] = ""
            self.settings.save()

            self.notice("Original mascot restored.")

        except Exception as exc:
            messagebox.showerror(
                APP_NAME,
                f"Couldn't restore the original mascot:\n{exc}"
            )

    # ---------- rare biome sound -------------------------------------------

    def _update_rare_sound_label(self):
        if not hasattr(self, "rare_sound_label"):
            return

        path = self.settings.get(
            "rare_custom_sound",
            ""
        )

        if path and os.path.isfile(path):
            self.rare_sound_label.configure(
                text=f"Selected: {os.path.basename(path)}",
                fg=GOOD
            )
        else:
            self.rare_sound_label.configure(
                text="Using the default ConeMacro rare sound.",
                fg=MUTED
            )

    def _sound_result(self, ok, msg):
        """Called from the sound thread; shows the real outcome in the app."""
        self.engine.events.put(
            ("notice", "Custom sound played fine.")
            if ok
            else ("error", f"Custom sound failed: {msg}")
        )

    def choose_rare_sound(self):
        path = filedialog.askopenfilename(
            title="Choose your rare biome alert sound",
            filetypes=[
                ("Audio files", "*.wav *.mp3 *.wma *.m4a *.aac"),
                ("All files", "*.*")
            ]
        )

        if not path:
            return

        problem = sound.check_file(path)

        if problem:
            messagebox.showerror(APP_NAME, problem)
            return

        path = os.path.abspath(os.path.normpath(path))

        self.settings["rare_custom_sound"] = path
        self.settings.save()

        self._update_rare_sound_label()

        # Play it right away so you can hear (or see why not) immediately.
        sound.preview(path, self._sound_result)
        self.notice("Custom sound saved. Playing it now...")

    def preview_rare_sound(self):
        path = self.settings.get(
            "rare_custom_sound",
            ""
        )

        if not path or not os.path.isfile(path):
            self.notice(
                "Choose a custom sound first.",
                bad=True
            )
            return

        problem = sound.preview(path, self._sound_result)

        if problem:
            messagebox.showerror(APP_NAME, problem)
            return

        self.notice("Playing your custom sound...")

    def reset_rare_sound(self):
        self.settings["rare_custom_sound"] = ""
        self.settings.save()

        sound.stop()
        self._update_rare_sound_label()

        self.notice("Default rare biome sound restored.")

    # ---------- accent and theme -------------------------------------------

    def choose_accent(self):
        color = colorchooser.askcolor(
            title="Choose an accent color",
            initialcolor=ORANGE
        )

        if not color or not color[1]:
            return

        self.settings["appearance_accent"] = color[1]
        self.settings.save()

        self.apply_theme()

    def reset_accent(self):
        self.settings["appearance_accent"] = ""
        self.settings.save()

        self.apply_theme()

    def apply_theme(self):
        global BG, PANEL, PANEL2
        global ORANGE, ORANGE_D
        global TEXT, MUTED, GOOD, BAD

        old = {
            "BG": BG,
            "PANEL": PANEL,
            "PANEL2": PANEL2,
            "ORANGE": ORANGE,
            "ORANGE_D": ORANGE_D,
            "TEXT": TEXT,
            "MUTED": MUTED,
            "GOOD": GOOD,
            "BAD": BAD,
        }

        theme_name = self.theme_var.get()

        theme = THEMES.get(
            theme_name,
            THEMES["Midnight"]
        )

        BG = theme["BG"]
        PANEL = theme["PANEL"]
        PANEL2 = theme["PANEL2"]
        ORANGE = theme["ORANGE"]
        ORANGE_D = theme["ORANGE_D"]
        TEXT = theme["TEXT"]
        MUTED = theme["MUTED"]
        GOOD = theme["GOOD"]
        BAD = theme["BAD"]

        accent = self.settings.get(
            "appearance_accent",
            ""
        )

        if accent:
            try:
                ORANGE = accent
                ORANGE_D = self._darken_color(accent)
            except Exception:
                pass

        replacements = {
            old["BG"]: BG,
            old["PANEL"]: PANEL,
            old["PANEL2"]: PANEL2,
            old["ORANGE"]: ORANGE,
            old["ORANGE_D"]: ORANGE_D,
            old["TEXT"]: TEXT,
            old["MUTED"]: MUTED,
            old["GOOD"]: GOOD,
            old["BAD"]: BAD,
        }

        def recolor(widget):
            for opt in (
                "bg",
                "fg",
                "highlightbackground",
                "highlightcolor",
                "activebackground",
                "activeforeground",
                "insertbackground",
                "selectcolor",
            ):
                try:
                    value = widget.cget(opt)

                    if value in replacements:
                        widget.configure(**{opt: replacements[value]})
                except Exception:
                    pass

            for child in widget.winfo_children():
                recolor(child)

        recolor(self.root)

        self.root.configure(bg=BG)
        self.wallpaper_canvas.configure(bg=BG)

        self._style()

        if hasattr(self, "canvas"):
            self.canvas.configure(bg=PANEL)

        self.settings["appearance_theme"] = theme_name
        self.settings.save()

        self.notice(f"{theme_name} theme applied.")

    def save_appearance_options(self):
        self.settings["appearance_animations"] = bool(
            self.animations_var.get()
        )

        self.settings.save()
        self.notice("Appearance preferences saved.")

    def _build_appearance(self):
        p = self._page("Appearance", scrollable=True)

        panel = tk.Frame(
            p,
            bg=PANEL,
            highlightthickness=1,
            highlightbackground="#382b20"
        )

        panel.pack(
            fill="both",
            expand=True,
            padx=2,
            pady=2
        )

        self.label(
            panel,
            "APPEARANCE",
            17,
            True,
            TEXT
        ).pack(
            anchor="w",
            padx=18,
            pady=(16, 4)
        )

        self.label(
            panel,
            "Customize the look and personality of ConeMacro.",
            9,
            False,
            MUTED
        ).pack(
            anchor="w",
            padx=18,
            pady=(0, 14)
        )

        self.label(
            panel,
            "COLOR THEME",
            10,
            True,
            ORANGE
        ).pack(
            anchor="w",
            padx=18,
            pady=(4, 5)
        )

        self.theme_var = tk.StringVar(
            value=self.settings.get(
                "appearance_theme",
                "Midnight"
            )
        )

        self.theme_combo = ttk.Combobox(
            panel,
            textvariable=self.theme_var,
            values=list(THEMES.keys()),
            state="readonly",
            width=25
        )

        self.theme_combo.pack(
            anchor="w",
            padx=18,
            pady=(0, 12)
        )

        self.theme_combo.bind(
            "<<ComboboxSelected>>",
            lambda _event: self.apply_theme()
        )

        tk.Frame(
            panel,
            bg="#382b20",
            height=1
        ).pack(
            fill="x",
            padx=18,
            pady=8
        )

        self.label(
            panel,
            "ACCENT COLOR",
            10,
            True,
            ORANGE
        ).pack(
            anchor="w",
            padx=18,
            pady=(4, 5)
        )

        accent_row = tk.Frame(
            panel,
            bg=PANEL
        )

        accent_row.pack(
            anchor="w",
            padx=18,
            pady=(0, 12)
        )

        self.button(
            accent_row,
            "Choose custom accent",
            self.choose_accent,
            True
        ).pack(side="left")

        self.button(
            accent_row,
            "Reset accent",
            self.reset_accent
        ).pack(
            side="left",
            padx=8
        )

        tk.Frame(
            panel,
            bg="#382b20",
            height=1
        ).pack(
            fill="x",
            padx=18,
            pady=8
        )

        self.label(
            panel,
            "DASHBOARD MASCOT",
            10,
            True,
            ORANGE
        ).pack(
            anchor="w",
            padx=18,
            pady=(4, 5)
        )

        self.label(
            panel,
            "Pick any image for the dashboard character. It is resized to fit automatically.",
            9,
            False,
            MUTED
        ).pack(
            anchor="w",
            padx=18,
            pady=(0, 7)
        )

        mascot_row = tk.Frame(
            panel,
            bg=PANEL
        )

        mascot_row.pack(
            anchor="w",
            padx=18,
            pady=(0, 12)
        )

        self.button(
            mascot_row,
            "Choose mascot image",
            self.choose_mascot,
            True
        ).pack(side="left")

        self.button(
            mascot_row,
            "Restore original",
            self.reset_mascot
        ).pack(
            side="left",
            padx=8
        )

        tk.Frame(
            panel,
            bg="#382b20",
            height=1
        ).pack(
            fill="x",
            padx=18,
            pady=8
        )

        self.label(
            panel,
            "BACKGROUND IMAGE",
            10,
            True,
            ORANGE
        ).pack(
            anchor="w",
            padx=18,
            pady=(4, 5)
        )

        self.label(
            panel,
            "Pick an image to place behind the interface. It stretches to fit the window as you resize it.",
            9,
            False,
            MUTED
        ).pack(
            anchor="w",
            padx=18,
            pady=(0, 7)
        )

        background_row = tk.Frame(
            panel,
            bg=PANEL
        )

        background_row.pack(
            anchor="w",
            padx=18,
            pady=(0, 12)
        )

        self.button(
            background_row,
            "Choose background",
            self.choose_background,
            True
        ).pack(side="left")

        self.button(
            background_row,
            "Remove background",
            self.remove_background
        ).pack(
            side="left",
            padx=8
        )

        tk.Frame(
            panel,
            bg="#382b20",
            height=1
        ).pack(
            fill="x",
            padx=18,
            pady=8
        )

        # Custom rare biome sound controls.
        self.label(
            panel,
            "RARE BIOME ALERT SOUND",
            10,
            True,
            ORANGE
        ).pack(
            anchor="w",
            padx=18,
            pady=(4, 5)
        )

        self.label(
            panel,
            "Choose a WAV or MP3 to play whenever a Rare, Special or Dev biome is detected.",
            9,
            False,
            MUTED,
            wraplength=700,
            justify="left"
        ).pack(
            anchor="w",
            padx=18,
            pady=(0, 7)
        )

        self.rare_sound_label = self.label(
            panel,
            "",
            9,
            False,
            MUTED
        )

        self.rare_sound_label.pack(
            anchor="w",
            padx=18,
            pady=(0, 8)
        )

        rare_sound_row = tk.Frame(
            panel,
            bg=PANEL
        )

        rare_sound_row.pack(
            anchor="w",
            padx=18,
            pady=(0, 12)
        )

        self.button(
            rare_sound_row,
            "Choose sound",
            self.choose_rare_sound,
            True
        ).pack(side="left")

        self.button(
            rare_sound_row,
            "Preview",
            self.preview_rare_sound
        ).pack(
            side="left",
            padx=8
        )

        self.button(
            rare_sound_row,
            "Restore default",
            self.reset_rare_sound
        ).pack(side="left")

        self._update_rare_sound_label()

        tk.Frame(
            panel,
            bg="#382b20",
            height=1
        ).pack(
            fill="x",
            padx=18,
            pady=8
        )

        self.animations_var = tk.BooleanVar(
            value=self.settings.get(
                "appearance_animations",
                True
            )
        )

        tk.Checkbutton(
            panel,
            text="Enable mascot animations",
            variable=self.animations_var,
            bg=PANEL,
            fg=TEXT,
            selectcolor=PANEL2,
            activebackground=PANEL,
            activeforeground=TEXT,
            highlightthickness=0,
            font=("Segoe UI", 10)
        ).pack(
            anchor="w",
            padx=18,
            pady=5
        )

        self.button(
            panel,
            "Save appearance preferences",
            self.save_appearance_options,
            True
        ).pack(
            anchor="w",
            padx=18,
            pady=14
        )

    # ---------- styling -----------------------------------------------------

    def _style(self):
        st = ttk.Style()
        st.theme_use("clam")

        st.configure(
            "Treeview",
            background=PANEL,
            fieldbackground=PANEL,
            foreground=TEXT,
            rowheight=36,
            borderwidth=0,
            font=("Segoe UI", 10)
        )

        st.configure(
            "Treeview.Heading",
            background=PANEL2,
            foreground=ORANGE,
            relief="flat",
            font=("Segoe UI", 9, "bold"),
            padding=(10, 9)
        )

        st.map(
            "Treeview",
            background=[("selected", "#49371d")],
            foreground=[("selected", TEXT)]
        )

        for sb_style in ("Vertical.TScrollbar", "TScrollbar"):
            st.configure(
                sb_style,
                background=PANEL2,
                troughcolor=PANEL,
                bordercolor=PANEL,
                lightcolor=PANEL2,
                darkcolor=PANEL2,
                arrowcolor=MUTED,
                relief="flat",
                arrowsize=14
            )

            st.map(
                sb_style,
                background=[("active", lighten(PANEL2, 0.15))]
            )

        st.configure(
            "TCombobox",
            fieldbackground=PANEL2,
            background=PANEL2,
            foreground=TEXT,
            arrowcolor=ORANGE
        )

        st.map(
            "TCombobox",
            fieldbackground=[("readonly", PANEL2)],
            foreground=[("readonly", TEXT)]
        )

    def label(
        self,
        parent,
        text="",
        size=10,
        bold=False,
        color=TEXT,
        **kw
    ):
        return tk.Label(
            parent,
            text=text,
            bg=kw.pop("bg", parent["bg"]),
            fg=color,
            font=(
                "Segoe UI",
                size,
                "bold" if bold else "normal"
            ),
            **kw
        )

    def button(self, parent, text, cmd, primary=False):
        return RoundedButton(parent, text, cmd, primary=primary)

    # ---------- header / nav -----------------------------------------------

    def _header(self):
        h = tk.Frame(
            self.root,
            bg=PANEL,
            highlightthickness=1,
            highlightbackground="#382b20"
        )

        h.pack(
            fill="x",
            padx=20,
            pady=(18, 14)
        )

        try:
            self._avatar = tk.PhotoImage(
                file=asset("avatar_small.png")
            )

            tk.Label(
                h,
                image=self._avatar,
                bg=PANEL
            ).pack(
                side="left",
                padx=(10, 8),
                pady=8
            )

        except Exception:
            pass

        box = tk.Frame(
            h,
            bg=PANEL
        )

        box.pack(side="left")

        self.label(
            box,
            APP_NAME,
            19,
            True,
            ORANGE
        ).pack(anchor="w")

        self.status = self.label(
            box,
            "●  STOPPED  ·  Ready to monitor",
            9,
            True,
            MUTED
        )

        self.status.pack(anchor="w")

        self.toggle_btn = self.button(
            h,
            "Start",
            self.toggle,
            True
        )

        self.toggle_btn.pack(
            side="right",
            padx=12
        )

        # Hidden until a special account is detected.
        self.love_btn = tk.Button(
            h,
            text="♥  Open me",
            command=self.play_love,
            relief="flat",
            cursor="hand2",
            bg="#ff4fa0",
            fg="#1a0710",
            activebackground="#ff7aa8",
            activeforeground="#1a0710",
            font=("Segoe UI", 10, "bold"),
            padx=14,
            pady=7,
            bd=0,
            highlightthickness=0
        )

        self.love_btn.bind(
            "<Enter>",
            lambda _e: self.love_btn.configure(bg="#ff7aa8")
        )
        self.love_btn.bind(
            "<Leave>",
            lambda _e: self.love_btn.configure(bg="#ff4fa0")
        )

        self._love_visible = False

    def _nav(self):
        bar = tk.Frame(
            self.root,
            bg=PANEL,
            width=190,
            highlightthickness=1,
            highlightbackground="#382b20"
        )

        bar.pack(
            side="left",
            fill="y",
            padx=(18, 12),
            pady=(0, 18)
        )

        bar.pack_propagate(False)

        self._nav_btns = {}

        self.label(
            bar,
            "WORKSPACE",
            8,
            True,
            MUTED
        ).pack(
            anchor="w",
            padx=16,
            pady=(18, 10)
        )

        for name, glyph in (
            ("Dashboard", "▦"),
            ("History", "◷"),
            ("Stats", "▥"),
            ("Account", "♙"),
            ("Settings", "⚙"),
            ("Appearance", "◈"),
        ):
            b = RoundedButton(
                bar, f"{glyph}   {name}",
                lambda n=name: self.show(n),
                primary=False, width=154, height=42, anchor="w"
            )
            b.configure(bg=PANEL, fg=MUTED)
            b.pack(fill="x", padx=8, pady=3)

            self._nav_btns[name] = b

        tk.Frame(
            bar,
            bg="#382b20",
            height=1
        ).pack(
            fill="x",
            padx=14,
            pady=(14, 10)
        )

        self.label(
            bar,
            "CONE MACRO",
            8,
            True,
            ORANGE
        ).pack(
            anchor="w",
            padx=16
        )

        self.label(
            bar,
            f"Version {APP_VERSION}",
            8,
            False,
            MUTED
        ).pack(
            anchor="w",
            padx=16,
            pady=(3, 0)
        )

    def show(self, name):
        self._current_page = name

        for n, f in self._pages.items():
            f.pack_forget()

            self._nav_btns[n].configure(
                fg=MUTED,
                bg=PANEL
            )

        self._pages[name].pack(
            fill="both",
            expand=True,
            pady=(4, 0)
        )

        self._nav_btns[name].configure(
            fg=ORANGE,
            bg=PANEL2
        )

        # Set the currently active scrollable page.
        self._active_scroll_canvas = self._scroll_canvases.get(name)

        # Bind mouse-wheel scrolling once.
        if not self._mousewheel_bound:
            self.root.bind_all(
                "<MouseWheel>",
                self._on_mousewheel
            )
            self.root.bind_all(
                "<Button-4>",
                self._on_mousewheel
            )
            self.root.bind_all(
                "<Button-5>",
                self._on_mousewheel
            )
            self._mousewheel_bound = True

    def _page(self, name, scrollable=True):
        """Every page lives in a scroll area, so nothing gets squashed
        or overlapped when the window is small."""
        page = tk.Frame(
            self._body,
            bg=BG
        )

        self._pages[name] = page

        container = tk.Frame(
            page,
            bg=BG
        )

        container.pack(
            fill="both",
            expand=True
        )

        container.rowconfigure(0, weight=1)
        container.columnconfigure(0, weight=1)

        canvas = tk.Canvas(
            container,
            bg=BG,
            highlightthickness=0,
            bd=0
        )

        scrollbar = ttk.Scrollbar(
            container,
            orient="vertical",
            command=canvas.yview
        )

        canvas.grid(row=0, column=0, sticky="nsew")
        scrollbar.grid(row=0, column=1, sticky="ns")

        def on_scroll(lo, hi):
            scrollbar.set(lo, hi)

            # Hide the scrollbar when everything already fits.
            if float(lo) <= 0.0 and float(hi) >= 1.0:
                scrollbar.grid_remove()
            else:
                scrollbar.grid()

        canvas.configure(yscrollcommand=on_scroll)

        content = tk.Frame(
            canvas,
            bg=BG
        )

        window_id = canvas.create_window(
            (0, 0),
            window=content,
            anchor="nw"
        )

        def fit(_event=None):
            width = max(1, canvas.winfo_width())
            height = max(
                canvas.winfo_height(),
                content.winfo_reqheight()
            )

            canvas.itemconfigure(
                window_id,
                width=width,
                height=height
            )

            canvas.configure(
                scrollregion=(0, 0, width, height)
            )

        content.bind("<Configure>", fit)
        canvas.bind("<Configure>", fit)

        self._scroll_canvases[name] = canvas

        return content

    def _on_mousewheel(self, event):
        canvas = self._active_scroll_canvas

        if canvas is None:
            return

        if not canvas.winfo_exists():
            return

        # Only scroll when the mouse is over the active canvas.
        mouse_x = self.root.winfo_pointerx()
        mouse_y = self.root.winfo_pointery()

        # Lists, tables and text boxes scroll themselves.
        try:
            under = self.root.winfo_containing(mouse_x, mouse_y)
        except Exception:
            under = None

        if isinstance(under, (ttk.Treeview, tk.Listbox, tk.Text)):
            return

        left = canvas.winfo_rootx()
        top = canvas.winfo_rooty()
        right = left + canvas.winfo_width()
        bottom = top + canvas.winfo_height()

        if not (
            left <= mouse_x <= right
            and top <= mouse_y <= bottom
        ):
            return

        if getattr(event, "num", None) == 4:
            canvas.yview_scroll(-1, "units")

        elif getattr(event, "num", None) == 5:
            canvas.yview_scroll(1, "units")

        else:
            delta = getattr(event, "delta", 0)

            if delta:
                units = int(-delta / 120)

                if units == 0:
                    units = -1 if delta > 0 else 1

                canvas.yview_scroll(
                    units,
                    "units"
                )

    # ---------- dashboard ---------------------------------------------------

    def _build_dashboard(self):
        p = self._page("Dashboard")

        left = tk.Frame(
            p,
            bg=PANEL,
            width=250,
            highlightthickness=1,
            highlightbackground="#382b20"
        )

        left.pack(
            side="left",
            fill="y",
            padx=(0, 12)
        )

        left.pack_propagate(False)

        self.canvas = tk.Canvas(
            left,
            width=250,
            height=420,
            bg=PANEL,
            highlightthickness=0
        )

        self.canvas.pack(pady=6)

        mascot_path = self.settings.get(
            "appearance_mascot",
            ""
        )

        try:
            try:
                if not (mascot_path and os.path.isfile(mascot_path)):
                    raise OSError("no custom mascot")

                self._mascot = fit_image(mascot_path, *MASCOT_BOX)
            except Exception:
                self._mascot = fit_image(
                    asset("mascot.png"),
                    *MASCOT_BOX
                )

            self.mascot_item = self.canvas.create_image(
                125,
                410,
                image=self._mascot,
                anchor="s"
            )

        except Exception:
            self.mascot_item = self.canvas.create_text(
                125,
                330,
                text="(mascot missing)",
                fill=MUTED
            )

        self.bubble_rect = self.canvas.create_rectangle(
            0,
            0,
            0,
            0,
            fill=TEXT,
            outline=ORANGE,
            width=2
        )

        self.bubble_text = self.canvas.create_text(
            125,
            60,
            text="",
            fill="#1a1209",
            width=190,
            font=("Segoe UI", 11, "bold"),
            justify="center"
        )

        self.say(
            "Press Start and I'll watch your game!",
            8
        )

        right = tk.Frame(
            p,
            bg=BG
        )

        right.pack(
            side="left",
            fill="both",
            expand=True
        )

        now = tk.Frame(
            right,
            bg=PANEL,
            highlightthickness=1,
            highlightbackground="#382b20"
        )

        now.pack(fill="x")

        self.label(
            now,
            "RIGHT NOW",
            9,
            True,
            ORANGE
        ).pack(
            anchor="w",
            padx=14,
            pady=(10, 2)
        )

        self.now_box = tk.Frame(
            now,
            bg=PANEL
        )

        self.now_box.pack(
            fill="x",
            padx=14,
            pady=(0, 12)
        )

        self.now_empty = self.label(
            self.now_box,
            "Not watching yet.",
            11,
            False,
            MUTED
        )

        self.now_empty.pack(anchor="w")

        self._now_rows = {}

        cards = tk.Frame(
            right,
            bg=BG
        )

        cards.pack(
            fill="x",
            pady=12
        )

        self.cards = {}

        for i, (key, title) in enumerate((
            ("time", "Session time"),
            ("biomes", "Biomes this session"),
            ("rares", "Rares this session"),
            ("since", "Since last rare")
        )):
            c = tk.Frame(
                cards,
                bg=PANEL,
                highlightthickness=1,
                highlightbackground="#382b20"
            )

            c.grid(
                row=0,
                column=i,
                sticky="nsew",
                padx=(0 if i == 0 else 8, 0)
            )

            cards.columnconfigure(
                i,
                weight=1
            )

            self.label(
                c,
                title.upper(),
                8,
                True,
                MUTED
            ).pack(
                anchor="w",
                padx=12,
                pady=(10, 0)
            )

            v = self.label(
                c,
                "0",
                20,
                True,
                TEXT
            )

            v.pack(
                anchor="w",
                padx=12,
                pady=(0, 10)
            )

            self.cards[key] = v

        feed = tk.Frame(
            right,
            bg=PANEL,
            highlightthickness=1,
            highlightbackground="#382b20"
        )

        feed.pack(
            fill="both",
            expand=True
        )

        self.label(
            feed,
            "LATEST",
            9,
            True,
            ORANGE
        ).pack(
            anchor="w",
            padx=14,
            pady=(10, 4)
        )

        self.feed_box = tk.Frame(
            feed,
            bg=PANEL
        )

        self.feed_box.pack(
            fill="both",
            expand=True,
            padx=14
        )

        self.msg = self.label(
            feed,
            "",
            9,
            False,
            MUTED
        )

        self.msg.pack(
            anchor="w",
            padx=14,
            pady=(0, 8)
        )

    def say(self, text, seconds=7):
        self.canvas.itemconfigure(
            self.bubble_text,
            text=text
        )

        x1, y1, x2, y2 = self.canvas.bbox(
            self.bubble_text
        )

        self.canvas.coords(
            self.bubble_rect,
            x1 - 10,
            y1 - 8,
            x2 + 10,
            y2 + 8
        )

        self.bubble_until = time.time() + seconds

    def _hide_bubble(self):
        self.canvas.itemconfigure(
            self.bubble_text,
            text=""
        )

        self.canvas.coords(
            self.bubble_rect,
            0,
            0,
            0,
            0
        )

    def _animate(self):
        t = time.time()

        if not self.settings.get(
            "appearance_animations",
            True
        ):
            self.canvas.coords(
                self.mascot_item,
                125,
                410
            )

            if self.bubble_until and t > self.bubble_until:
                self.bubble_until = 0
                self._hide_bubble()
                self.last_idle = t

            self.root.after(
                100,
                self._animate
            )

            return

        if self.engine.running:
            dy = math.sin(t * 2.4) * 4
        else:
            dy = math.sin(t * 1.2) * 1.5

        self.canvas.coords(
            self.mascot_item,
            125,
            410 + dy
        )

        if self.bubble_until and t > self.bubble_until:
            self.bubble_until = 0
            self._hide_bubble()
            self.last_idle = t

        elif (
            not self.bubble_until
            and self.engine.running
            and t - self.last_idle > 25
        ):
            self.say(
                random.choice(IDLE_LINES),
                5
            )

        self.root.after(
            50,
            self._animate
        )

    # ---------- history / stats --------------------------------------------

    def _tree(self, parent, cols, widths):
        wrap = tk.Frame(
            parent,
            bg=PANEL
        )

        wrap.pack(
            fill="both",
            expand=True
        )

        tree = ttk.Treeview(
            wrap,
            columns=cols,
            show="headings",
            selectmode="browse"
        )

        for c, w in zip(cols, widths):
            tree.heading(c, text=c)
            tree.column(
                c,
                width=w,
                anchor="w"
            )

        sb = ttk.Scrollbar(
            wrap,
            orient="vertical",
            command=tree.yview
        )

        tree.configure(
            yscrollcommand=sb.set
        )

        tree.pack(
            side="left",
            fill="both",
            expand=True
        )

        sb.pack(
            side="right",
            fill="y"
        )

        for tier, color in TIER_COLOR.items():
            tree.tag_configure(
                tier,
                foreground=color
            )

        return tree

    def _build_history(self):
        p = self._page("History")

        self.hist_tree = self._tree(
            p,
            ("Time", "Window", "Biome", "Tier"),
            (180, 140, 260, 120)
        )

    def _hist_insert(self, row, index=0):
        when = time.strftime(
            "%Y-%m-%d %H:%M:%S",
            time.localtime(row["t"])
        )

        self.hist_tree.insert(
            "",
            index,
            values=(
                when,
                row["inst"],
                row["name"],
                row["tier"]
            ),
            tags=(row["tier"],)
        )

    def _load_history_rows(self):
        for row in self.history.rows[-300:]:
            self._hist_insert(row)

    def _build_stats(self):
        p = self._page("Stats")

        # Header and at-a-glance totals.
        top = tk.Frame(p, bg=BG)
        top.pack(fill="x", pady=(0, 12))

        heading = tk.Frame(top, bg=BG)
        heading.pack(side="left", fill="x", expand=True)
        self.label(heading, "Biome statistics", 18, True, TEXT).pack(anchor="w")
        self.label(
            heading,
            "A breakdown of every biome you've discovered",
            9, False, MUTED
        ).pack(anchor="w", pady=(2, 0))

        self.stats_total = self.label(
            top, "0 total", 10, True, GOOD,
            bg="#17251b", padx=12, pady=7
        )
        self.stats_total.pack(side="right", anchor="ne", pady=4)

        # Spotlight cards focus on rare and special discoveries.
        self.stats_spotlight = tk.Frame(
            p, bg=PANEL, highlightthickness=1,
            highlightbackground="#49371d"
        )
        self.stats_spotlight.pack(fill="x", pady=(0, 14))

        spot_head = tk.Frame(self.stats_spotlight, bg=PANEL)
        spot_head.pack(fill="x", padx=14, pady=(11, 8))
        self.label(
            spot_head, "✦  RARE BIOME SPOTLIGHT", 9, True, ORANGE
        ).pack(side="left")
        self.label(
            spot_head, "LIFETIME DISCOVERIES", 8, True, MUTED
        ).pack(side="right")

        self.stats_spot_cards = tk.Frame(self.stats_spotlight, bg=PANEL)
        self.stats_spot_cards.pack(fill="x", padx=10, pady=(0, 11))

        # Grouped biome list.
        self.stats_groups = tk.Frame(p, bg=BG)
        self.stats_groups.pack(fill="x")
        self.stats_group_widgets = []

    @staticmethod
    def _stats_color(value):
        try:
            return "#{:06x}".format(int(value) & 0xFFFFFF)
        except (TypeError, ValueError):
            return "#8a8f9b"

    def refresh_stats(self):
        if not hasattr(self, "stats_groups"):
            return

        life = self.history.lifetime_counts()
        sess = self.history.session_counts()
        known = [b for b in ALL if b.tier != "none"]
        extras = sorted(k for k in life if k not in BY_KEY)
        total = sum(life.values())
        self.stats_total.configure(text=f"{total:,} total")

        # Rare + special discoveries get the spotlight. Keep a stable,
        # predictable order rather than sorting by the current count.
        spotlight = [
            b for b in known if b.tier in ("rare", "special")
        ]
        spotlight.sort(
            key=lambda b: (0 if b.tier == "rare" else 1, b.name)
        )
        spotlight = spotlight[:4]

        for child in self.stats_spot_cards.winfo_children():
            child.destroy()

        for col, biome in enumerate(spotlight):
            count = life.get(biome.key, 0)
            session_count = sess.get(biome.key, 0)
            color = self._stats_color(biome.color)
            card = tk.Frame(
                self.stats_spot_cards, bg="#17120e",
                highlightthickness=1, highlightbackground="#49371d"
            )
            card.grid(
                row=0, column=col, sticky="nsew",
                padx=(0 if col == 0 else 7, 0)
            )
            self.stats_spot_cards.columnconfigure(col, weight=1)
            line = tk.Frame(card, bg="#17120e")
            line.pack(fill="x", padx=10, pady=(10, 3))
            tk.Frame(line, bg=color, width=11, height=11).pack(
                side="left", pady=2
            )
            self.label(
                line, biome.name, 9, True, TEXT
            ).pack(side="left", padx=(7, 0))
            self.label(
                card, f"{count:,}", 21, True, TEXT
            ).pack(anchor="w", padx=10)
            self.label(
                card, f"{session_count:,} THIS SESSION", 7, True, MUTED
            ).pack(anchor="w", padx=10, pady=(0, 9))

        for child in self.stats_groups.winfo_children():
            child.destroy()

        tier_order = ("rare", "special", "dev", "event", "common", "unknown")
        tier_names = {
            "rare": "RARE", "special": "SPECIAL", "dev": "DEVELOPER",
            "event": "EVENT", "common": "NORMAL", "unknown": "UNCLASSIFIED"
        }
        tier_colors = {
            "rare": "#f4c542", "special": "#b58aff", "dev": "#ff7777",
            "event": "#e7a94c", "common": "#8993a5", "unknown": "#8ab4ff"
        }
        max_count = max([life.get(b.key, 0) for b in known] +
                        [life.get(k, 0) for k in extras] + [1])

        for tier in tier_order:
            rows = [b for b in known if b.tier == tier]
            if tier == "unknown":
                rows += [
                    type("UnknownBiome", (), {
                        "key": k, "name": k, "tier": "unknown",
                        "color": 0x8AB4FF
                    })() for k in extras
                ]
            if not rows:
                continue

            rows.sort(key=lambda b: (-life.get(b.key, 0), b.name.lower()))
            subtotal = sum(life.get(b.key, 0) for b in rows)
            section = tk.Frame(
                self.stats_groups, bg=PANEL,
                highlightthickness=1, highlightbackground="#382b20"
            )
            section.pack(fill="x", pady=(0, 10))

            head = tk.Frame(section, bg=PANEL)
            head.pack(fill="x", padx=13, pady=(10, 7))
            tk.Frame(
                head, bg=tier_colors[tier], width=8, height=8
            ).pack(side="left", pady=3)
            self.label(
                head, tier_names[tier], 8, True, tier_colors[tier]
            ).pack(side="left", padx=(8, 0))
            self.label(
                head, f"{subtotal:,}", 8, True, MUTED
            ).pack(side="right")

            for biome in rows:
                count = life.get(biome.key, 0)
                session_count = sess.get(biome.key, 0)
                color = self._stats_color(biome.color)
                row = tk.Frame(section, bg="#17120e")
                row.pack(fill="x", padx=10, pady=(0, 7))

                left = tk.Frame(row, bg="#17120e", width=180)
                left.pack(side="left", fill="y", padx=(10, 8), pady=8)
                left.pack_propagate(False)
                tk.Frame(
                    left, bg=color, width=10, height=10
                ).pack(side="left", pady=3)
                self.label(
                    left, biome.name, 9, True, TEXT
                ).pack(side="left", padx=(8, 0))

                middle = tk.Frame(row, bg="#17120e")
                middle.pack(side="left", fill="both", expand=True, pady=8)
                bar = tk.Canvas(
                    middle, height=8, bg="#2a211a",
                    highlightthickness=0, bd=0
                )
                bar.pack(fill="x", expand=True, pady=(3, 0))
                fraction = count / max_count if max_count else 0
                bar.bind(
                    "<Configure>",
                    lambda event, c=bar, f=fraction, col=color:
                        (c.delete("fill"),
                         c.create_rectangle(
                             0, 0, max(0, event.width * f), 8,
                             fill=col, outline="", tags="fill"
                         ))
                )
                bar.create_rectangle(
                    0, 0, 0, 8, fill=color, outline="", tags="fill"
                )

                sub = self.label(
                    middle,
                    f"{session_count:,} this session  ·  {count:,} lifetime",
                    7, False, MUTED
                )
                sub.pack(anchor="w", pady=(5, 0))

                self.label(
                    row, f"{count:,}", 10, True, TEXT,
                    bg="#17120e", width=7, anchor="e"
                ).pack(side="right", padx=(8, 12), pady=8)

    # ---------- account -----------------------------------------------------

    def _build_account(self):
        p = self._page("Account", scrollable=True)

        header = tk.Frame(
            p,
            bg=BG
        )

        header.pack(
            fill="x",
            pady=(0, 12)
        )

        self.label(
            header,
            "ACCOUNT MANAGER",
            17,
            True,
            TEXT
        ).pack(anchor="w")

        self.label(
            header,
            "Enter each exact Roblox username. ConeMacro matches it "
            "against the username found in that client log; assign "
            "manually if it cannot match.",
            9,
            False,
            MUTED
        ).pack(
            anchor="w",
            pady=(3, 0)
        )

        panel = tk.Frame(
            p,
            bg=PANEL,
            highlightthickness=1,
            highlightbackground="#382b20"
        )

        panel.pack(
            fill="both",
            expand=True
        )

        top = tk.Frame(
            panel,
            bg=PANEL
        )

        top.pack(
            fill="x",
            padx=16,
            pady=(14, 8)
        )

        self.label(
            top,
            "SAVED ACCOUNTS",
            10,
            True,
            ORANGE
        ).pack(side="left")

        self.label(
            top,
            "No passwords or Roblox cookies are needed",
            8,
            False,
            MUTED
        ).pack(side="right")

        cols = ("name", "server")

        self.account_tree = ttk.Treeview(
            panel,
            columns=cols,
            show="headings",
            height=7,
            selectmode="browse"
        )

        self.account_tree.heading(
            "name",
            text="ROBLOX USERNAME"
        )

        self.account_tree.heading(
            "server",
            text="PRIVATE SERVER LINK"
        )

        self.account_tree.column(
            "name",
            width=210,
            anchor="w"
        )

        self.account_tree.column(
            "server",
            width=520,
            anchor="w"
        )

        self.account_tree.pack(
            fill="x",
            padx=16,
            pady=(0, 8)
        )

        actions = tk.Frame(
            panel,
            bg=PANEL
        )

        actions.pack(
            fill="x",
            padx=16,
            pady=(0, 12)
        )

        self.button(
            actions,
            "Remove selected",
            self.remove_account
        ).pack(side="left")

        tk.Frame(
            panel,
            bg="#382b20",
            height=1
        ).pack(
            fill="x",
            padx=16,
            pady=5
        )

        self.label(
            panel,
            "ADD AN ACCOUNT",
            10,
            True,
            ORANGE
        ).pack(
            anchor="w",
            padx=16,
            pady=(8, 5)
        )

        form = tk.Frame(
            panel,
            bg=PANEL
        )

        form.pack(
            fill="x",
            padx=16,
            pady=(0, 12)
        )

        self.label(
            form,
            "Display name",
            9,
            False,
            MUTED
        ).grid(
            row=0,
            column=0,
            sticky="w",
            pady=(2, 4)
        )

        self.e_account_name = tk.Entry(
            form,
            bg=PANEL2,
            fg=TEXT,
            insertbackground=TEXT,
            relief="flat",
            highlightthickness=1,
            highlightbackground=PANEL2,
            highlightcolor=ORANGE,
            font=("Segoe UI", 10)
        )

        self.e_account_name.grid(
            row=1,
            column=0,
            sticky="ew",
            padx=(0, 10),
            ipady=7
        )

        self.label(
            form,
            "Private server share link",
            9,
            False,
            MUTED
        ).grid(
            row=0,
            column=1,
            sticky="w",
            pady=(2, 4)
        )

        self.e_private_link = tk.Entry(
            form,
            bg=PANEL2,
            fg=TEXT,
            insertbackground=TEXT,
            relief="flat",
            highlightthickness=1,
            highlightbackground=PANEL2,
            highlightcolor=ORANGE,
            font=("Segoe UI", 10)
        )

        self.e_private_link.grid(
            row=1,
            column=1,
            sticky="ew",
            padx=(0, 10),
            ipady=7
        )

        self.button(
            form,
            "+ Add account",
            self.save_account,
            True
        ).grid(
            row=1,
            column=2,
            sticky="ew"
        )

        form.columnconfigure(0, weight=1)
        form.columnconfigure(1, weight=2)

        tk.Frame(
            panel,
            bg="#382b20",
            height=1
        ).pack(
            fill="x",
            padx=16,
            pady=5
        )

        self.label(
            panel,
            "INSTANCE ROUTING",
            10,
            True,
            ORANGE
        ).pack(
            anchor="w",
            padx=16,
            pady=(8, 2)
        )

        self.label(
            panel,
            "Assign the matching saved Roblox account to each detected "
            "instance. Unassigned instances use the primary saved "
            "profile in Multi-Macro Mode.",
            9,
            False,
            MUTED,
            wraplength=760,
            justify="left"
        ).pack(
            anchor="w",
            padx=16,
            pady=(0, 8)
        )

        self.instance_route_box = tk.Frame(
            panel,
            bg=PANEL
        )

        self.instance_route_box.pack(
            fill="x",
            padx=16,
            pady=(0, 12)
        )

        self._account_vars = {}

        self._refresh_account_tree()
        self._render_instance_routes()

    def _refresh_account_tree(self):
        if not hasattr(self, "account_tree"):
            return

        for item in self.account_tree.get_children():
            self.account_tree.delete(item)

        for account in self.settings.get("accounts", []):
            link = account.get(
                "private_server_link",
                ""
            )

            self.account_tree.insert(
                "",
                "end",
                iid=account["id"],
                values=(
                    account.get("name", ""),
                    link or "Not set"
                )
            )

    def save_account(self):
        name = self.e_account_name.get().strip()
        link = self.e_private_link.get().strip()

        if not name:
            messagebox.showwarning(
                APP_NAME,
                "Enter the exact Roblox username for automatic log matching."
            )
            return

        if link and not (
            link.startswith("https://www.roblox.com/")
            or link.startswith("https://roblox.com/")
        ):
            messagebox.showwarning(
                APP_NAME,
                "Please enter a Roblox private-server share link "
                "beginning with https://www.roblox.com/."
            )
            return

        accounts = self.settings.get(
            "accounts",
            []
        )

        if any(
            a.get("name", "").casefold() == name.casefold()
            for a in accounts
        ):
            messagebox.showwarning(
                APP_NAME,
                "That account name has already been added."
            )
            return

        accounts.append({
            "id": uuid.uuid4().hex[:10],
            "name": name,
            "private_server_link": link
        })

        self.settings["accounts"] = accounts
        self.settings.save()

        self.e_account_name.delete(0, "end")
        self.e_private_link.delete(0, "end")

        self._refresh_account_tree()
        self._render_instance_routes()

        self.notice(f"Added account {name}.")

    def remove_account(self):
        selected = self.account_tree.selection()

        if not selected:
            self.notice(
                "Select an account to remove.",
                bad=True
            )
            return

        account_id = selected[0]

        accounts = self.settings.get(
            "accounts",
            []
        )

        name = next(
            (
                a.get("name", "account")
                for a in accounts
                if a.get("id") == account_id
            ),
            "account"
        )

        if not messagebox.askyesno(
            APP_NAME,
            f"Remove {name} from ConeMacro?"
        ):
            return

        self.settings["accounts"] = [
            a for a in accounts
            if a.get("id") != account_id
        ]

        assignments = self.settings.get(
            "instance_accounts",
            {}
        )

        self.settings["instance_accounts"] = {
            k: v
            for k, v in assignments.items()
            if v != account_id
        }

        self.settings.save()

        self._refresh_account_tree()
        self._render_instance_routes()

        self.notice(f"Removed {name}.")

    def _render_instance_routes(self):
        if not hasattr(self, "instance_route_box"):
            return

        for child in self.instance_route_box.winfo_children():
            child.destroy()

        accounts = self.settings.get("accounts", [])

        choices = ["Unassigned"] + [
            a.get("name", "Account")
            for a in accounts
        ]

        by_name = {
            a.get("name", ""): a.get("id")
            for a in accounts
        }

        assignments = self.settings.get(
            "instance_accounts",
            {}
        )

        if not self.engine.instances:
            self.label(
                self.instance_route_box,
                "No Roblox instances detected yet. Press Start to "
                "discover running game windows.",
                9,
                False,
                MUTED
            ).pack(anchor="w")

            return

        self._route_vars = {}

        for label in self.engine.instances:
            row = tk.Frame(
                self.instance_route_box,
                bg=PANEL2
            )

            row.pack(
                fill="x",
                pady=3
            )

            self.label(
                row,
                label,
                9,
                True,
                TEXT
            ).pack(
                side="left",
                padx=10,
                pady=7
            )

            current_id = assignments.get(label)

            matched_account = next(
                (
                    a for a in accounts
                    if str(a.get("name", "")).strip().casefold()
                    == label.casefold()
                    or label.casefold().startswith(
                        str(a.get("name", "")).strip().casefold() + " ("
                    )
                ),
                None
            )

            if not current_id and matched_account:
                current_id = matched_account.get("id")

            current_name = next(
                (
                    a.get("name")
                    for a in accounts
                    if a.get("id") == current_id
                ),
                "Unassigned"
            )

            var = tk.StringVar(value=current_name)
            self._route_vars[label] = var

            combo = ttk.Combobox(
                row,
                textvariable=var,
                values=choices,
                state="readonly",
                width=28
            )

            combo.pack(
                side="right",
                padx=8,
                pady=5
            )

            combo.bind(
                "<<ComboboxSelected>>",
                lambda _e, instance=label, v=var:
                self._save_route(
                    instance,
                    v.get(),
                    by_name
                )
            )

    def _save_route(self, instance, account_name, by_name):
        assignments = self.settings.get(
            "instance_accounts",
            {}
        )

        if account_name == "Unassigned":
            assignments.pop(instance, None)
        else:
            assignments[instance] = by_name.get(account_name)

        self.settings["instance_accounts"] = assignments
        self.settings.save()

        self.notice(
            f"{instance} is now routed to {account_name}."
        )

    # ---------- settings ----------------------------------------------------

    def _build_settings(self):
        p = self._page("Settings")

        box = tk.Frame(
            p,
            bg=PANEL,
            highlightthickness=1,
            highlightbackground="#382b20"
        )

        box.pack(
            fill="both",
            expand=True,
            padx=2,
            pady=2
        )

        s = self.settings

        pad = {
            "padx": 14,
            "pady": 4
        }

        r = 0

        def row(text, widget_factory):
            nonlocal r

            self.label(
                box,
                text,
                10,
                False,
                MUTED
            ).grid(
                row=r,
                column=0,
                sticky="w",
                **pad
            )

            w = widget_factory()

            w.grid(
                row=r,
                column=1,
                columnspan=4,
                sticky="ew",
                ipady=4,
                **pad
            )

            r += 1

        def entry(value, show=""):
            e = tk.Entry(
                box,
                bg=PANEL2,
                fg=TEXT,
                insertbackground=TEXT,
                relief="flat",
                highlightthickness=1,
                highlightbackground=PANEL2,
                highlightcolor=ORANGE,
                show=show,
                font=("Segoe UI", 10)
            )

            e.insert(0, value)
            return e

        self.label(
            box,
            "SETTINGS",
            17,
            True,
            TEXT
        ).grid(
            row=r,
            column=0,
            columnspan=5,
            sticky="w",
            padx=14,
            pady=(14, 6)
        )

        r += 1

        self.e_webhook = entry(s["webhook_url"])
        row("Discord webhook URL", lambda: self.e_webhook)

        self.e_mention = entry(s["mention"])
        row("Ping text (e.g. <@yourID>)", lambda: self.e_mention)

        self.e_logdir = entry(s["log_dir"])
        row("Roblox log folder (blank = auto)", lambda: self.e_logdir)

        self.v_multi_macro = tk.BooleanVar(
            value=bool(s.get("multi_macro_enabled", False))
        )

        multi_row = tk.Frame(
            box,
            bg=PANEL
        )

        multi_row.grid(
            row=r,
            column=0,
            columnspan=5,
            sticky="ew",
            padx=14,
            pady=(10, 4)
        )

        tk.Checkbutton(
            multi_row,
            text="Enable Multi-Macro Mode",
            variable=self.v_multi_macro,
            bg=PANEL,
            fg=TEXT,
            selectcolor=PANEL2,
            activebackground=PANEL,
            activeforeground=TEXT,
            highlightthickness=0,
            font=("Segoe UI", 10, "bold")
        ).pack(anchor="w")

        self.label(
            multi_row,
            "OFF: monitor the most recently active Roblox log only.  "
            "ON: monitor every active Roblox log and match each "
            "detected username to its saved account profile.",
            8,
            False,
            MUTED,
            wraplength=760,
            justify="left"
        ).pack(
            anchor="w",
            padx=(24, 0),
            pady=(2, 0)
        )

        r += 1

        self.label(
            box,
            "Alerts by tier",
            10,
            True,
            ORANGE
        ).grid(
            row=r,
            column=0,
            sticky="w",
            padx=14,
            pady=(14, 2)
        )

        for i, head in enumerate(("Webhook", "@Ping", "Sound")):
            self.label(
                box,
                head,
                9,
                True,
                MUTED
            ).grid(
                row=r,
                column=2 + i,
                pady=(14, 2)
            )

        r += 1

        self.tier_vars = {}

        for tier in TIERS:
            self.label(
                box,
                tier.capitalize(),
                10,
                False,
                TIER_COLOR[tier]
            ).grid(
                row=r,
                column=0,
                sticky="w",
                **pad
            )

            for i, group in enumerate((
                "webhook_tiers",
                "ping_tiers",
                "sound_tiers"
            )):
                v = tk.BooleanVar(
                    value=bool(s[group].get(tier))
                )

                self.tier_vars[(group, tier)] = v

                tk.Checkbutton(
                    box,
                    variable=v,
                    bg=PANEL,
                    activebackground=PANEL,
                    selectcolor=PANEL2,
                    highlightthickness=0
                ).grid(
                    row=r,
                    column=2 + i
                )

            r += 1

        self.v_sound = tk.BooleanVar(value=s["sound_enabled"])
        self.v_afk = tk.BooleanVar(value=s["antiafk_enabled"])
        self.v_sum = tk.BooleanVar(value=s["session_summary"])

        self.v_mins = tk.StringVar(
            value=str(s["antiafk_minutes"])
        )

        for text, var in (
            ("Play alert sounds", self.v_sound),
            (
                "Send a session summary to Discord when I press Stop",
                self.v_sum
            ),
            (
                "Anti-AFK (taps Space in Roblox windows; briefly takes focus)",
                self.v_afk
            )
        ):
            tk.Checkbutton(
                box,
                text=text,
                variable=var,
                bg=PANEL,
                fg=TEXT,
                selectcolor=PANEL2,
                activebackground=PANEL,
                activeforeground=TEXT,
                highlightthickness=0,
                font=("Segoe UI", 10)
            ).grid(
                row=r,
                column=0,
                columnspan=5,
                sticky="w",
                **pad
            )

            r += 1

        f = tk.Frame(
            box,
            bg=PANEL
        )

        f.grid(
            row=r,
            column=0,
            columnspan=5,
            sticky="w",
            **pad
        )

        self.label(
            f,
            "Anti-AFK every",
            10,
            False,
            MUTED
        ).pack(side="left")

        tk.Spinbox(
            f,
            from_=1,
            to=19,
            width=4,
            textvariable=self.v_mins,
            bg=PANEL2,
            fg=TEXT,
            relief="flat",
            buttonbackground=PANEL2
        ).pack(
            side="left",
            padx=6
        )

        self.label(
            f,
            "minutes (Roblox kicks at 20)",
            10,
            False,
            MUTED
        ).pack(side="left")

        r += 1

        hk = tk.Frame(
            box,
            bg=PANEL
        )

        hk.grid(
            row=r,
            column=0,
            columnspan=5,
            sticky="w",
            padx=14,
            pady=(10, 4)
        )

        self.label(
            hk,
            "Start / Stop hotkey",
            10,
            False,
            MUTED
        ).pack(side="left")

        self.hotkey_btn = self.button(
            hk,
            "",
            self.capture_hotkey
        )
        self.hotkey_btn.pack(side="left", padx=(12, 6))

        self.button(
            hk,
            "Clear",
            self.clear_hotkey
        ).pack(side="left", padx=(0, 6))

        self.button(
            hk,
            f"Reset ({hotkey.DEFAULT_HOTKEY})",
            self.reset_hotkey
        ).pack(side="left")

        self._refresh_hotkey_ui()

        r += 1

        btns = tk.Frame(
            box,
            bg=PANEL
        )

        btns.grid(
            row=r,
            column=0,
            columnspan=5,
            sticky="w",
            padx=14,
            pady=16
        )

        self.button(
            btns,
            "Save",
            self.save_settings,
            True
        ).pack(side="left")

        self.button(
            btns,
            "Test webhook",
            self.test_webhook
        ).pack(
            side="left",
            padx=8
        )

        self.button(
            btns,
            "Test sound",
            lambda: sound.play(
                "rare",
                custom_path=self.settings.get(
                    "rare_custom_sound",
                    ""
                ),
                on_error=lambda m: self.engine.events.put(
                    ("error", f"Custom sound: {m}")
                ),
                on_result=self._sound_result
            )
        ).pack(side="left")

        box.columnconfigure(1, weight=1)

        for col in (2, 3, 4):
            box.columnconfigure(col, minsize=84)

    def save_settings(self, quiet=False):
        s = self.settings

        s["webhook_url"] = self.e_webhook.get().strip()
        s["mention"] = self.e_mention.get().strip()
        s["log_dir"] = self.e_logdir.get().strip()

        s["multi_macro_enabled"] = bool(
            self.v_multi_macro.get()
        )

        for (group, tier), var in self.tier_vars.items():
            s[group][tier] = bool(var.get())

        s["sound_enabled"] = bool(self.v_sound.get())
        s["antiafk_enabled"] = bool(self.v_afk.get())
        s["session_summary"] = bool(self.v_sum.get())

        try:
            s["antiafk_minutes"] = min(
                19,
                max(1, int(self.v_mins.get()))
            )
        except ValueError:
            s["antiafk_minutes"] = 10

        s.save()

        if not quiet:
            self.notice(
                "Settings saved. Multi-Macro changes apply "
                "next time you press Start."
            )

    def test_webhook(self):
        self.save_settings(quiet=True)

        url = self.settings["webhook_url"]

        if not url.startswith("https://"):
            messagebox.showwarning(
                APP_NAME,
                "Paste a Discord webhook URL first "
                "(it starts with https://)."
            )
            return

        webhook.send(
            url,
            webhook.text_payload(
                f"{APP_NAME} test",
                "If you can read this, webhooks work!"
            ),
            lambda m: self.engine.events.put(
                ("error", f"Webhook test failed: {m}")
            ),
            lambda status: self.engine.events.put(
                (
                    "notice",
                    f"Webhook test delivered (HTTP {status})."
                )
            ),
        )

        self.notice("Sending webhook test...")

    # ---------- runtime -----------------------------------------------------

    def toggle(self):
        if self.engine.running:
            self.engine.stop()
        else:
            self.save_settings(quiet=True)
            self.engine.start()

    def notice(self, text, bad=False):
        self.msg.configure(
            text=text,
            fg=BAD if bad else MUTED
        )

    def _set_status(self, running):
        self.status.configure(
            text=(
                "●  LIVE  ·  Monitoring Roblox logs"
                if running
                else "●  STOPPED  ·  Ready to monitor"
            ),
            fg=GOOD if running else MUTED
        )

        self._running_label = running
        self._refresh_toggle_label()

        self.say(
            "Okay, I'm watching!"
            if running
            else "Taking a break~",
            5
        )

    def _render_now(self):
        for w in self.now_box.winfo_children():
            w.destroy()

        self._now_rows = {}

        if hasattr(self, "instance_route_box"):
            self._render_instance_routes()

        if not self.engine.instances:
            text = (
                "Looking for a Roblox log with Sol's RNG running..."
                if self.engine.running
                else "Not watching yet."
            )

            self.label(
                self.now_box,
                text,
                11,
                False,
                MUTED
            ).pack(anchor="w")

            return

        for lbl, info in self.engine.instances.items():
            f = tk.Frame(
                self.now_box,
                bg=PANEL
            )

            f.pack(
                fill="x",
                pady=2
            )

            b = info["biome"]

            account = self.engine._account_for_instance(lbl)

            instance_name = (
                lbl
                if account and lbl.casefold()
                == str(account.get("name", "")).casefold()
                else (
                    f"{lbl} · {account.get('name')}"
                    if account
                    else lbl
                )
            )

            self.label(
                f,
                instance_name,
                9,
                False,
                MUTED,
                width=24,
                anchor="w"
            ).pack(side="left")

            self.label(
                f,
                b.name,
                12,
                True,
                TIER_COLOR.get(b.tier, TEXT)
            ).pack(
                side="left",
                padx=8
            )

            timer = self.label(
                f,
                "",
                10,
                False,
                MUTED
            )

            timer.pack(side="right")

            self._now_rows[lbl] = timer

    def _poll(self):
        try:
            while True:
                ev = self.engine.events.get_nowait()
                kind = ev[0]

                if kind == "status":
                    self._set_status(ev[1])
                    self._render_now()

                elif kind == "hotkey":
                    was_running = self.engine.running
                    self.toggle()
                    self.notice(
                        "Stopped with the hotkey."
                        if was_running
                        else "Started with the hotkey."
                    )

                elif kind == "state":
                    self._render_now()

                elif kind == "biome":
                    _, label, biome, row = ev

                    self._hist_insert(row)
                    self._render_now()
                    self.refresh_stats()
                    self._add_feed(label, biome, row)

                    if biome.tier != "none":
                        self.say(
                            random.choice(
                                REACT.get(
                                    biome.tier,
                                    REACT["common"]
                                )
                            ).format(b=biome.name),
                            10 if biome.tier in (
                                "rare",
                                "special",
                                "dev"
                            ) else 6
                        )

                elif kind == "afk":
                    self.notice(
                        f"Anti-AFK tapped Space in {ev[1]} Roblox window(s)."
                        if ev[1]
                        else "Anti-AFK: no Roblox window found."
                    )

                elif kind == "error":
                    self.notice(ev[1], bad=True)

                elif kind == "notice":
                    self.notice(ev[1])

        except Exception:
            pass

        self.root.after(200, self._poll)

    def _add_feed(self, label, biome, row):
        existing = self.feed_box.winfo_children()

        f = tk.Frame(
            self.feed_box,
            bg=PANEL
        )

        if existing:
            f.pack(
                fill="x",
                pady=1,
                before=existing[0]
            )
        else:
            f.pack(
                fill="x",
                pady=1
            )

        when = time.strftime(
            "%H:%M:%S",
            time.localtime(row["t"])
        )

        self.label(
            f,
            when,
            9,
            False,
            MUTED
        ).pack(side="left")

        self.label(
            f,
            f"{label}: {biome.name}",
            10,
            True,
            TIER_COLOR.get(biome.tier, TEXT)
        ).pack(
            side="left",
            padx=8
        )

        for extra in self.feed_box.winfo_children()[8:]:
            extra.destroy()

    def _tick(self):
        e = self.engine
        now = time.time()

        self._update_love_button()

        self.cards["time"].configure(
            text=(
                fmt_clock(now - e.started_at)
                if e.running
                else "--:--"
            )
        )

        sess = self.history.session_rows

        self.cards["biomes"].configure(
            text=str(
                sum(
                    1 for r in sess
                    if r["tier"] != "none"
                )
            )
        )

        self.cards["rares"].configure(
            text=str(
                sum(
                    1 for r in sess
                    if r["tier"] in ("rare", "special")
                )
            )
        )

        self.cards["since"].configure(
            text=str(self.history.since_rare)
        )

        for lbl, timer in self._now_rows.items():
            info = e.instances.get(lbl)

            if info and info["since"] and info["biome"].duration:
                left = (
                    info["since"]
                    + info["biome"].duration
                    - now
                )

                timer.configure(
                    text=(
                        f"about {fmt_clock(left)} left"
                        if left > 0
                        else "should be ending"
                    )
                )
            else:
                timer.configure(text="")

        self.root.after(1000, self._tick)

    # ---------- hotkey ------------------------------------------------------

    def _refresh_toggle_label(self):
        running = getattr(self, "_running_label", False)
        spec = self.settings.get("hotkey", "")
        base = "Stop" if running else "Start"

        self.toggle_btn.configure(
            text=f"{base}  ({spec})" if spec else base
        )

    def _refresh_hotkey_ui(self):
        spec = self.settings.get("hotkey", "")

        if hasattr(self, "hotkey_btn"):
            self.hotkey_btn.configure(
                text=spec if spec else "None (disabled)"
            )

        if hasattr(self, "toggle_btn"):
            self._refresh_toggle_label()

    def capture_hotkey(self):
        if self._hotkey_capturing:
            return

        self._hotkey_capturing = True
        self.hotkey_btn.configure(text="Press a key...  (Esc cancels)")

        # Move focus off the button so Space can't re-click it.
        self.root.focus_force()
        self._hotkey_bind = self.root.bind(
            "<KeyPress>",
            self._on_hotkey_key,
            add="+"
        )

    def _end_hotkey_capture(self):
        self._hotkey_capturing = False

        if self._hotkey_bind:
            try:
                self.root.unbind("<KeyPress>", self._hotkey_bind)
            except tk.TclError:
                pass

            self._hotkey_bind = None

        self._refresh_hotkey_ui()

    def _on_hotkey_key(self, event):
        if not self._hotkey_capturing:
            return None

        if event.keysym == "Escape":
            self._end_hotkey_capture()
            return "break"

        spec = hotkey.spec_from_event(event)

        if spec is None:
            return "break"  # only a modifier so far; keep waiting

        if not hotkey.is_safe(spec):
            self._end_hotkey_capture()
            self.notice(
                f"'{spec}' would fire while you type. Use an F-key, or "
                "add Ctrl / Alt / Shift.",
                bad=True
            )
            return "break"

        self.settings["hotkey"] = spec
        self.settings.save()
        self._end_hotkey_capture()
        self.notice(f"Start/Stop hotkey set to {spec}.")
        return "break"

    def clear_hotkey(self):
        self.settings["hotkey"] = ""
        self.settings.save()
        self._refresh_hotkey_ui()
        self.notice("Hotkey disabled.")

    def reset_hotkey(self):
        self.settings["hotkey"] = hotkey.DEFAULT_HOTKEY
        self.settings.save()
        self._refresh_hotkey_ui()
        self.notice(f"Hotkey reset to {hotkey.DEFAULT_HOTKEY}.")

    def _tk_hotkey(self, event):
        spec = self.settings.get("hotkey", "")

        if (
            spec
            and not self._hotkey_capturing
            and hotkey.spec_from_event(event) == spec
        ):
            self.engine.events.put(("hotkey",))

    # ---------- a little surprise -------------------------------------------

    def _love_names(self):
        """Every Roblox username we can currently tie to this macro."""
        names = set()

        def add(value):
            value = str(value or "").split(" (")[0].strip().casefold()

            if value:
                names.add(value)

        e = self.engine

        # Roblox clients the log watcher is following (works even before
        # the first biome has been read).
        try:
            tracked = list(getattr(e._watcher, "_files", {}).values())
        except Exception:
            tracked = []

        labels = [t.label for t in tracked]

        for t in tracked:
            add(t.label)
            add(getattr(t, "username", ""))

        labels += list(e.instances)

        for label in labels:
            add(label)

            try:
                account = e._account_for_instance(label)
            except Exception:
                account = None

            if account:
                add(account.get("name"))

        # Saved account profiles.
        for account in self.settings.get("accounts", []):
            add(account.get("name"))

        return names

    def _love_detected(self):
        """True when one of the special accounts is in use."""
        if "--love-preview" in sys.argv:
            return True

        try:
            return bool(self._love_names() & LOVE_ACCOUNTS)
        except Exception:
            return False

    def _update_love_button(self):
        show = self._love_detected()

        if show and not self._love_visible:
            self.love_btn.pack(side="right", padx=(0, 4))
            self._love_visible = True
            self.say("Psst... I have something for you ♥", 12)

        elif not show and self._love_visible:
            self.love_btn.pack_forget()
            self._love_visible = False

    def play_love(self):
        if getattr(self, "_love_scene", None) and self._love_scene.alive:
            return

        try:
            icon = fit_image(asset("icon.png"), 120, 120)
        except Exception:
            icon = None

        self._love_pic = self._mascot or icon
        self._love_scene = LoveCutscene(
            self.root,
            mascot=self._love_pic,
            icon=icon
        )

    def close(self):
        try:
            self._hotkeys.stop()
            self.engine.stop()
            self.settings.save()
            self.history.save_state()
        finally:
            time.sleep(0.2)
            self.root.destroy()