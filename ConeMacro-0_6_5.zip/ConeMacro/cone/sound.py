
"""Alert sounds: built-in Windows beeps and custom WAV files."""

import os
import sys
import threading
import time

PATTERNS = {
    "rare": [(880, 120), (1175, 120), (1568, 120), (2093, 260)],
    "special": [(660, 150), (990, 150), (1320, 300)],
    "dev": [(523, 120), (784, 120), (1047, 120), (1568, 120), (2093, 300)],
    "event": [(700, 140), (900, 200)],
    "common": [(600, 120)],
    "unknown": [(500, 120), (700, 120)],
}

_lock = threading.Lock()


def _play_builtin(tier):
    pattern = PATTERNS.get(tier, PATTERNS["common"])

    try:
        import winsound

        for freq, ms in pattern:
            winsound.Beep(freq, ms)

    except Exception:
        sys.stdout.write("\a")
        sys.stdout.flush()
        time.sleep(0.05)


SUPPORTED_EXT = (".wav", ".mp3", ".wma", ".m4a", ".aac")
IS_WINDOWS = sys.platform == "win32"

_current_alias = None
_alias_counter = 0


def check_wav(path):
    """Return None if the file is a readable PCM WAV, else a reason string."""
    import wave

    if not path or not os.path.isfile(path):
        return "The file could not be found."

    try:
        with wave.open(path, "rb") as w:
            if w.getnframes() <= 0:
                return "The WAV file is empty."
    except Exception:
        return (
            "That WAV isn't a standard PCM WAV (it may be float, ADPCM, "
            "or just a renamed MP3)."
        )

    return None


def check_file(path):
    """Cheap sanity check for a chosen sound file (None = looks fine)."""
    if not path or not os.path.isfile(path):
        return "The file could not be found."

    if not path.lower().endswith(SUPPORTED_EXT):
        return "Please choose a .wav or .mp3 file."

    if os.path.getsize(path) == 0:
        return "That audio file is empty."

    return None


def _winsound_play(path):
    """Play a WAV and wait for it to finish. Returns (ok, message)."""
    try:
        import winsound

        winsound.PlaySound(
            path,
            winsound.SND_FILENAME | winsound.SND_NODEFAULT
        )
        return True, ""

    except Exception as exc:
        return False, f"winsound: {exc}"


def _mci_play(path):
    """Play wav/mp3/wma through Windows' media engine; waits until done.

    Returns (ok, message).
    """
    global _current_alias, _alias_counter

    try:
        import ctypes

        winmm = ctypes.windll.winmm
    except Exception as exc:
        return False, f"MCI unavailable: {exc}"

    _alias_counter += 1
    alias = f"conesnd{_alias_counter}"
    buf = ctypes.create_unicode_buffer(256)

    def send(command):
        err = winmm.mciSendStringW(command, buf, 255, 0)

        if not err:
            return ""

        text = ctypes.create_unicode_buffer(256)
        winmm.mciGetErrorStringW(err, text, 255)
        return text.value or f"MCI error {err}"

    clean = path.replace('"', "")
    problem = send(f'open "{clean}" alias {alias}')

    if problem:
        # mp3 / aac often need the explicit MPEG type.
        problem = send(f'open "{clean}" type mpegvideo alias {alias}')

    if problem:
        return False, f"MCI: {problem}"

    _current_alias = alias

    try:
        problem = send(f"play {alias} wait")
        return (not problem), (f"MCI: {problem}" if problem else "")
    finally:
        send(f"close {alias}")

        if _current_alias == alias:
            _current_alias = None


def _play_file(path):
    """Play a custom sound, waiting for it to end. Returns (ok, message)."""
    if not IS_WINDOWS:
        return False, "Custom sounds need Windows."

    problem = check_file(path)

    if problem:
        return False, problem

    # Backslashes + absolute path: the most compatible form for winmm.
    path = os.path.abspath(os.path.normpath(path))
    errors = []

    if path.lower().endswith(".wav"):
        ok, msg = _winsound_play(path)

        if ok:
            return True, ""

        errors.append(msg)

    ok, msg = _mci_play(path)

    if ok:
        return True, ""

    errors.append(msg)
    return False, "; ".join(e for e in errors if e) or "Could not play it."


def play(tier: str, custom_path: str = "", on_error=None, on_result=None):
    """Play a custom sound for Rare/Special/Dev, otherwise the beep pattern.

    on_error(msg)       called if the custom file fails (beep plays instead)
    on_result(ok, msg)  called after a custom-file attempt, either way
    """

    def work():
        with _lock:
            if tier in ("rare", "special", "dev") and custom_path:
                ok, msg = _play_file(custom_path)

                if on_result:
                    on_result(ok, msg)

                if ok:
                    return

                if on_error:
                    on_error(msg or "Custom sound failed to play.")

            _play_builtin(tier)

    threading.Thread(target=work, daemon=True, name="cone-sound").start()


def preview(path: str, on_result=None):
    """Play a chosen file once. Returns a reason string if it's unusable."""
    problem = check_file(path)

    if problem:
        return problem

    def work():
        with _lock:
            ok, msg = _play_file(path)

            if on_result:
                on_result(ok, msg)

    threading.Thread(target=work, daemon=True, name="cone-sound").start()
    return None


def stop():
    """Stop any custom sound that is currently playing."""
    try:
        import winsound

        winsound.PlaySound(None, winsound.SND_PURGE)
    except Exception:
        pass

    alias = _current_alias

    if alias and IS_WINDOWS:
        try:
            import ctypes

            ctypes.windll.winmm.mciSendStringW(f"stop {alias}", None, 0, 0)
        except Exception:
            pass
