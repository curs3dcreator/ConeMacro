"""ConeMacro - a small biome logger for Sol's RNG."""
APP_NAME = "ConeMacro"
APP_VERSION = "0.6.4"
