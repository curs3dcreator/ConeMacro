
"""Discord webhook sender (standard library only)."""
import json
import threading
import time
import urllib.request
from datetime import datetime, timezone

from . import APP_NAME


def _post(url: str, payload: dict):
    req = urllib.request.Request(
        url,
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            "User-Agent": f"{APP_NAME}/0.1",
        },
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=10) as resp:
        return resp.status


def send(url: str, payload: dict, on_error=None, on_success=None):
    """Send asynchronously and report the actual Discord response."""
    if not url:
        if on_error:
            on_error("No Discord webhook URL is configured.")
        return

    def work():
        for attempt in (1, 2):
            try:
                status = _post(url, payload)
                if on_success:
                    on_success(status)
                return
            except Exception as exc:
                if attempt == 2:
                    if on_error:
                        code = getattr(exc, "code", None)
                        detail = (
                            f"HTTP {code}"
                            if code
                            else "network or connection error"
                        )
                        on_error(f"{type(exc).__name__}: {detail}")
                    return

                time.sleep(1.5)

    threading.Thread(
        target=work,
        daemon=True,
        name="cone-webhook",
    ).start()


def biome_payload(
    biome,
    instance,
    mention="",
    ping=False,
    session_total=0,
    since_rare=0,
    account_name="",
    private_server_link="",
):
    pretty = {
        "rare": "RARE",
        "special": "SPECIAL",
        "dev": "DEV",
        "event": "EVENT",
    }.get(biome.tier, "")

    title = f"{biome.name} started!"

    if pretty:
        title = f"{pretty}: {biome.name} started!"

    fields = [
        {
            "name": "Account",
            "value": account_name or instance,
            "inline": True,
        },
        {
            "name": "Roblox instance",
            "value": instance,
            "inline": True,
        },
        {
            "name": "Seen this session",
            "value": str(session_total),
            "inline": True,
        },
    ]

    if biome.duration:
        end = int(time.time()) + biome.duration
        fields.append({
            "name": "Usually ends",
            "value": f"<t:{end}:R>",
            "inline": True,
        })

    if since_rare:
        fields.append({
            "name": "Biomes since last rare",
            "value": str(since_rare),
            "inline": True,
        })

    payload = {
        "content": mention if (ping and mention) else "",
        "embeds": [{
            "title": title,
            "color": biome.color,
            "fields": fields,
            "footer": {"text": APP_NAME},
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }],
    }

    if private_server_link:
        payload["components"] = [{
            "type": 1,
            "components": [{
                "type": 2,
                "style": 5,
                "label": "Join Private Server",
                "url": private_server_link,
            }],
        }]

    return payload


def biome_ended_payload(
    biome,
    instance,
    started_at=None,
    account_name="",
):
    """Create a Discord embed announcing that a biome has ended."""
    fields = [
        {
            "name": "Account",
            "value": account_name or instance,
            "inline": True,
        },
        {
            "name": "Roblox instance",
            "value": instance,
            "inline": True,
        },
    ]

    if started_at:
        elapsed = max(0, int(time.time() - started_at))
        hours, remainder = divmod(elapsed, 3600)
        minutes, seconds = divmod(remainder, 60)

        if hours:
            duration_text = f"{hours}h {minutes}m"
        elif minutes:
            duration_text = f"{minutes}m {seconds}s"
        else:
            duration_text = f"{seconds}s"

        fields.append({
            "name": "Time lasted",
            "value": duration_text,
            "inline": True,
        })

    return {
        "embeds": [{
            "title": f"{biome.name} ended!",
            "description": f"**{biome.name}** is no longer active in this Roblox instance.",
            "color": biome.color,
            "fields": fields,
            "footer": {"text": f"{APP_NAME} • Biome Tracker"},
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }],
    }


def text_payload(title: str, body: str, color: int = 0xFF8A1F):
    return {
        "embeds": [{
            "title": title,
            "description": body,
            "color": color,
            "footer": {"text": APP_NAME},
        }]
    }
