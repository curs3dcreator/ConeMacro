"""Biome table and name normalisation."""
import re
from dataclasses import dataclass


@dataclass(frozen=True)
class Biome:
    key: str
    name: str
    tier: str          # common | event | rare | special | dev | unknown | none
    color: int         # Discord embed colour
    duration: int = 0  # seconds the biome normally lasts (0 = unknown)
    aliases: tuple = ()  # other spellings the game / wiki uses


def _k(text: str) -> str:
    # Keep any letters/digits (including non-English ones), drop the rest.
    return re.sub(r"[\W_]+", "", text.lower())


# Source: the Sol's RNG wiki Biomes page (Eon 1-30) plus the Developer /
# Admin Abuse biome entries.
_TABLE = [
    Biome("normal", "Normal", "none", 0x7E8499),

    # ---- regular biomes -------------------------------------------------
    Biome("windy", "Windy", "common", 0xADD8E6, 120),
    Biome("rainy", "Rainy", "common", 0x4682B4, 120),
    Biome("snowy", "Snowy", "common", 0xDDEEFF, 120),
    Biome("sandstorm", "Sand Storm", "common", 0xF4A460, 650),
    Biome("hell", "Hell", "common", 0xFF2200, 666),
    Biome("starfall", "Starfall", "common", 0x4B50C8, 600),
    Biome("heaven", "Heaven", "common", 0xFFF2A8, 240),
    Biome("lostforest", "Lost Forest", "common", 0x3E8E41, 450),
    Biome("corruption", "Corruption", "common", 0x8B008B, 650),
    Biome("null", "Null", "common", 0x4A4A5A, 99),

    # ---- rare biomes ----------------------------------------------------
    Biome("glitched", "Glitched", "rare", 0x22DD55, 164),
    Biome("dreamspace", "Dreamspace", "rare", 0xFF69B4, 192),
    Biome("cyberspace", "Cyberspace", "rare", 0x00E5FF, 720),
    Biome(
        "theradiantforest", "The Radiant Forest", "rare", 0xFFE08A, 900,
        aliases=("radiantforest",),
    ),

    # ---- special --------------------------------------------------------
    Biome("singularity", "Singularity", "special", 0x8A2BE2, 1200),
    Biome("limbo", "Limbo", "special", 0x2B2B33, aliases=("thelimbo",)),

    # ---- event biomes ---------------------------------------------------
    Biome("graveyard", "Graveyard", "event", 0x708090),
    Biome("pumpkinmoon", "Pumpkin Moon", "event", 0xFF7518),
    Biome("bloodrain", "Blood Rain", "event", 0xB0121B, 600),
    Biome("blazingsun", "Blazing Sun", "event", 0xFF8C00),
    Biome("incinerator", "Incinerator", "event", 0xFF4500, 200),
    Biome("aurora", "Aurora", "event", 0x00FA9A),
    Biome("eggland", "Eggland", "event", 0xFFD1DC),

    # ---- developer / admin-abuse biomes ---------------------------------
    Biome(
        "thehyperspacerealm", "The Hyperspace Realm", "dev", 0x6A5CFF,
        aliases=("hyperspacerealm", "anotherrealm", "thecyberspacerealm"),
    ),
    Biome("abnormality", "Abnormality", "dev", 0x7A3FA0),
    Biome(
        "thenullsexistence", "The Null's Existence", "dev", 0x9AA0B5,
        aliases=("nullsexistence", "mastermind"),
    ),
    Biome(
        "thecitadeloforders", "The Citadel of Orders", "dev", 0xFFD700,
        aliases=("citadeloforders", "edict"),
    ),
    Biome(
        "theredfullmoon", "The Red Full Moon", "dev", 0xC1121F,
        aliases=("redfullmoon", "\u8d64\u3044\u6e80\u6708"),
    ),
    # Older developer-only biomes some wiki guides mention.
    Biome("theforgotten", "The Forgotten", "dev", 0x555566),
    Biome("overture", "Overture", "dev", 0xB48EAD),
]

BY_KEY = {}

for _b in _TABLE:
    BY_KEY[_b.key] = _b

    for _alias in _b.aliases:
        BY_KEY[_k(_alias)] = _b

ALL = list(_TABLE)
TIERS = ["rare", "special", "dev", "event", "common", "unknown"]


def lookup(raw: str) -> Biome:
    """Turn the game's hover text into a Biome. New/unknown biomes still work."""
    key = _k(raw)
    if key.endswith("biome"):
        key = key[:-5]
    if key in BY_KEY:
        return BY_KEY[key]
    return Biome(key or "unknown", raw.strip().title() or "Unknown", "unknown", 0x7E8499)
