
"""Glue: log watcher -> history -> alerts (webhook, sound) -> GUI events."""

import queue
import time

from . import sound, webhook
from .antiafk import AntiAfk
from .biomes import lookup
from .logwatch import LogWatcher


class Engine:
    def __init__(self, settings, history):
        self.settings, self.history = settings, history
        self.events = queue.Queue()
        self.instances = {}
        self.running = False
        self._watcher = None
        self._afk = None
        self.started_at = 0.0

    def start(self):
        if self.running:
            return

        self.running = True
        self.started_at = time.time()
        self.instances.clear()

        self._watcher = LogWatcher(
            self._on_biome,
            lambda: self.settings["log_dir"].strip(),
            multi_macro_fn=lambda: bool(
                self.settings.get("multi_macro_enabled", False)
            ),
            accounts_fn=lambda: self.settings.get("accounts", []),
        )
        self._watcher.start()

        if self.settings["antiafk_enabled"]:
            self._afk = AntiAfk(
                lambda: self.settings["antiafk_minutes"],
                self._on_afk,
            )
            self._afk.start()

        self.events.put(("status", True))

    def stop(self):
        if not self.running:
            return

        self.running = False

        for t in (self._watcher, self._afk):
            if t:
                t.stop()

        self._watcher = self._afk = None
        self._send_summary()
        self.events.put(("status", False))

    def _on_afk(self, count):
        self.events.put(("afk", count))

    def _on_biome(self, label, raw, silent):
        biome = lookup(raw)
        previous = self.instances.get(label)

        # A non-silent update means the watcher has detected a new
        # biome state for this Roblox instance.
        if not silent and previous:
            previous_biome = previous.get("biome")
            previous_since = previous.get("since")

            if (
                previous_biome
                and previous_biome.tier != "none"
                and previous_biome.key != biome.key
            ):
                self._send_biome_ended(
                    label,
                    previous_biome,
                    previous_since,
                )

        self.instances[label] = {
            "biome": biome,
            "since": time.time() if not silent else None,
        }

        if silent:
            self.events.put(("state", label, biome))
            return

        row = self.history.add(label, biome)
        s = self.settings
        tier = biome.tier
        counts = self.history.session_counts()

        if tier != "none":
            account = self._account_for_instance(label)

            destinations = self._destinations(tier)

            for url, ping, name in destinations:
                payload = webhook.biome_payload(
                    biome,
                    label,
                    s["mention"],
                    ping,
                    session_total=counts.get(biome.key, 0),
                    since_rare=self.history.since_rare,
                    account_name=(account or {}).get(
                        "name", s.get("account_name", "")
                    ),
                    private_server_link=(account or {}).get(
                        "private_server_link",
                        s.get("private_server_link", ""),
                    ),
                )

                webhook.send(
                    url,
                    payload,
                    lambda m, n=name: self.events.put(
                        ("error", f"Webhook {n} failed: {m}")
                    ),
                    lambda status, n=name: self.events.put(
                        (
                            "notice",
                            f"Biome alert delivered to {n} (HTTP {status}).",
                        )
                    ),
                )

            if not self._has_any_webhook():
                self.events.put((
                    "error",
                    "Webhook is not configured. Add its URL in Settings.",
                ))

            if s["sound_enabled"] and s["sound_tiers"].get(tier):
                custom_sound = ""

                if tier in ("rare", "special", "dev"):
                    custom_sound = s.get("rare_custom_sound", "")

                sound.play(
                    tier,
                    custom_path=custom_sound,
                    on_error=lambda m: self.events.put(
                        ("error", f"Custom sound: {m}")
                    ),
                )

        self.events.put(("biome", label, biome, row))

    def _send_biome_ended(self, label, biome, started_at):
        """Send an ended notification for the previous biome."""
        s = self.settings
        tier = biome.tier

        destinations = self._destinations(tier)

        if not destinations:
            return

        account = self._account_for_instance(label)

        payload = webhook.biome_ended_payload(
            biome,
            label,
            started_at=started_at,
            account_name=(account or {}).get(
                "name", s.get("account_name", "")
            ),
        )

        for url, _ping, name in destinations:
            webhook.send(
                url,
                payload,
                lambda m, n=name: self.events.put(
                    ("error", f"Biome-ended webhook {n} failed: {m}")
                ),
                lambda status, n=name: self.events.put(
                    (
                        "notice",
                        f"Biome-ended alert delivered to {n} (HTTP {status}).",
                    )
                ),
            )

    # ---------- webhook destinations ----------------------------------------

    def _destinations(self, tier):
        """[(url, ping, name)] for every webhook that wants this tier."""
        s = self.settings
        ping_tier = bool(s.get("ping_tiers", {}).get(tier))
        out = []

        if s.get("webhook_url") and s.get("webhook_tiers", {}).get(tier):
            out.append((s["webhook_url"], ping_tier, "main webhook"))

        for w in s.get("webhook_extra", []):
            url = str(w.get("url", "")).strip()

            if (
                w.get("enabled", True)
                and url.startswith("https://")
                and w.get("tiers", {}).get(tier)
            ):
                out.append((
                    url,
                    ping_tier and bool(w.get("ping", True)),
                    w.get("name") or "extra webhook",
                ))

        return out

    def _has_any_webhook(self):
        s = self.settings

        return bool(s.get("webhook_url")) or any(
            str(w.get("url", "")).startswith("https://")
            for w in s.get("webhook_extra", [])
            if w.get("enabled", True)
        )

    def all_webhook_urls(self):
        s = self.settings
        urls = [s["webhook_url"]] if s.get("webhook_url") else []

        urls += [
            w["url"].strip()
            for w in s.get("webhook_extra", [])
            if w.get("enabled", True)
            and str(w.get("url", "")).startswith("https://")
        ]

        return list(dict.fromkeys(urls))

    # ---------- log health --------------------------------------------------

    def log_idle_seconds(self):
        """Seconds since any watched Roblox log last grew (None if none)."""
        watcher = self._watcher

        if not (self.running and watcher):
            return None

        try:
            times = [t.last_growth for t in list(watcher._files.values())]
        except RuntimeError:
            return None

        return time.time() - max(times) if times else None

    def send_health_alert(self, title, text):
        for url in self.all_webhook_urls():
            webhook.send(url, webhook.text_payload(title, text))

    def _account_for_instance(self, label):
        """Resolve the profile assigned to a detected Roblox log."""
        accounts = self.settings.get("accounts", [])
        assignments = self.settings.get("instance_accounts", {})
        account_id = assignments.get(label)

        for account in accounts:
            if account.get("id") == account_id:
                return account

        normalized_label = str(label).strip().casefold()

        for account in accounts:
            account_name = str(account.get("name", "")).strip().casefold()

            if account_name and (
                normalized_label == account_name
                or normalized_label.startswith(account_name + " (")
            ):
                return account

        if accounts and (
            len(accounts) == 1
            or self.settings.get("multi_macro_enabled", False)
        ):
            return accounts[0]

        return None

    def _send_summary(self):
        s = self.settings
        rows = self.history.session_rows

        if not (s["session_summary"] and self.all_webhook_urls() and rows):
            return

        counts = self.history.session_counts()

        if not counts:
            return

        mins = int((time.time() - self.started_at) / 60)

        lines = [
            f"**{k}** x{v}"
            for k, v in sorted(
                counts.items(),
                key=lambda kv: -kv[1],
            )
        ]

        for url in self.all_webhook_urls():
            webhook.send(
                url,
                webhook.text_payload(
                    f"Session over ({mins} min)",
                    "\n".join(lines),
                ),
            )
