"""A little love-letter cutscene, shown only for a couple of special accounts.

Edit LOVE_SCENES below to change what it says. Each entry is one screen of
text. Use "\n" for a line break. The LAST entry is the big final screen.
"""
import math
import random
import time
import tkinter as tk

# Roblox usernames (any capitalisation) that unlock the button.
LOVE_ACCOUNTS = {"tanjiroacadamy", "officialcurs3d"}

# ---------------------------------------------------------------------------
# EDIT ME: the words of the cutscene.
# ---------------------------------------------------------------------------
LOVE_SCENES = [
    "Hey you.",

    "I wrote you something.\nIt took me a while,\nso read it slowly.",

    "They say the rarest things in life\ntake patience, luck, and time.\nI wasn't even looking, love,\nand still you turned out mine.",

    "You're the light when the sky goes grey,\nthe quiet when the world gets loud,\nthe first one I want to tell\nwhenever something makes me proud.",

    "On the days I'm tired and small,\nyou make me feel ten feet tall.\nOn the days I doubt it all,\nyou're the one who breaks my fall.",

    "I've watched a thousand ordinary hours\nturn golden just because you're there.\nYou make the plainest, smallest moments\nfeel like something rare.",

    "Glitched. Dreamspace. Cyberspace.\nI'd trade every single one\nfor one more ordinary evening\nwith you, when the day is done.",

    "You put up with my late-night code,\nmy messy, half-built schemes,\nand somehow you still look at me\nlike I'm made of better dreams.",

    "I love your laugh, your quiet side,\nyour every wonderful, weird little thing.\nYou're the reason this heart of mine\nhas learned how to sing.",

    "This little cone and all its quirks,\nevery button, every line,\nis just a very long way of saying\nI'm so glad that you are mine.",

    "So here's my promise, plain and true,\nno lag, no glitch, no fear:\nthrough every storm and every sun,\nI'm choosing you, right here.",

    "Thank you for being you.\nThank you for staying.\nThank you for being mine.",

    "I love you.",
]

CLOSE_TEXT = "Back to the macro"

BG = "#12080f"
TEXT = "#fff1f6"
HEARTS = ["#ff4fa0", "#ff7aa8", "#ff9b45", "#ffb3c8", "#ff6f91"]


def _hex(c):
    c = c.lstrip("#")
    return tuple(int(c[i:i + 2], 16) for i in (0, 2, 4))


def _mix(a, b, t):
    """Blend colour a toward colour b by t (0..1)."""
    t = max(0.0, min(1.0, t))
    ra, rb = _hex(a), _hex(b)
    return "#%02x%02x%02x" % tuple(int(x + (y - x) * t) for x, y in zip(ra, rb))


class LoveCutscene:
    FADE_IN, FADE_OUT = 1.0, 0.8

    def __init__(self, root, on_close=None, mascot=None, icon=None):
        self.root, self.on_close = root, on_close
        self.mascot, self.icon = mascot, icon
        self.alive = True
        self.hearts = []
        self.scene = 0
        self.scene_start = time.time()
        self.last_spawn = 0.0
        self.last_tick = time.time()
        self.button_shown = False

        self.frame = tk.Frame(root, bg=BG)
        self.frame.place(x=0, y=0, relwidth=1, relheight=1)
        self.frame.lift()

        self.canvas = tk.Canvas(self.frame, bg=BG, highlightthickness=0)
        self.canvas.pack(fill="both", expand=True)

        self.text = self.canvas.create_text(
            0, 0, text="", fill=BG, justify="center",
            font=("Segoe UI", 24, "bold"),
        )
        self.hint = self.canvas.create_text(
            0, 0, text="click or press Space to continue   ·   Esc to close",
            fill=_mix(BG, TEXT, 0.35), font=("Segoe UI", 9), anchor="se",
        )

        self.canvas.bind("<Button-1>", self._advance)

        self._binds = []

        for seq, fn in (
            ("<space>", self._advance),
            ("<Return>", self._advance),
            ("<Escape>", self.close),
        ):
            self._binds.append((seq, root.bind(seq, fn, add="+")))

        self.canvas.focus_force()
        self._tick()

    # -- helpers -----------------------------------------------------------

    def _size(self):
        return max(1, self.canvas.winfo_width()), max(1, self.canvas.winfo_height())

    def _is_final(self):
        return self.scene >= len(LOVE_SCENES) - 1

    def _hold_time(self):
        if self._is_final():
            return float("inf")
        return 2.0 + 0.055 * len(LOVE_SCENES[self.scene])

    def _advance(self, _event=None):
        if not self.alive or self._is_final():
            return

        # Jump straight to the fade-out of the current scene.
        t = time.time() - self.scene_start
        fade_start = self.FADE_IN + self._hold_time()

        if t < fade_start:
            self.scene_start = time.time() - fade_start

    def _spawn_heart(self, w, h, burst=False):
        size = random.choice((12, 14, 16, 20, 26, 34))
        color = random.choice(HEARTS)
        item = self.canvas.create_text(
            random.uniform(0, w), h + 30 if not burst else random.uniform(h * 0.4, h),
            text="♥", font=("Segoe UI Symbol", size), fill=BG,
        )
        self.canvas.tag_lower(item, self.text)
        self.hearts.append({
            "id": item, "x": random.uniform(0, w), "color": color,
            "speed": random.uniform(35, 105), "phase": random.uniform(0, 6.28),
            "sway": random.uniform(8, 28), "size": size,
            "y": h + 30 if not burst else random.uniform(h * 0.4, h),
        })

    # -- main loop ---------------------------------------------------------

    def _tick(self):
        if not self.alive:
            return

        now = time.time()
        dt = min(0.1, now - self.last_tick)
        self.last_tick = now
        w, h = self._size()
        final = self._is_final()

        # Hearts.
        rate = 0.12 if final else 0.35
        if now - self.last_spawn > rate:
            self.last_spawn = now
            self._spawn_heart(w, h)

        for heart in self.hearts[:]:
            heart["y"] -= heart["speed"] * dt
            x = heart["x"] + math.sin(now * 1.3 + heart["phase"]) * heart["sway"]
            fade = 0.22 + 0.5 * min(1.0, max(0.0, heart["y"] / max(1, h)))
            self.canvas.coords(heart["id"], x, heart["y"])
            self.canvas.itemconfigure(
                heart["id"], fill=_mix(BG, heart["color"], fade * (heart["size"] / 34 + 0.35))
            )
            if heart["y"] < -40:
                self.canvas.delete(heart["id"])
                self.hearts.remove(heart)

        # Text scene.
        t = now - self.scene_start
        hold = self._hold_time()
        alpha = 1.0

        if t < self.FADE_IN:
            alpha = t / self.FADE_IN
        elif t > self.FADE_IN + hold:
            alpha = 1 - (t - self.FADE_IN - hold) / self.FADE_OUT

            if alpha <= 0:
                self.scene += 1
                self.scene_start = now
                alpha = 0.0

        size = 40 if self._is_final() else 24
        pulse = 1 + 0.04 * math.sin(now * 3) if self._is_final() else 1
        self.canvas.itemconfigure(
            self.text,
            text=LOVE_SCENES[min(self.scene, len(LOVE_SCENES) - 1)],
            fill=_mix(BG, TEXT if not self._is_final() else "#ff9fc2", alpha),
            width=max(260, w - 160),
            font=("Segoe UI", int(size * pulse), "bold"),
        )
        self.canvas.coords(self.text, w / 2, h * (0.27 if self._is_final() else 0.5))
        self.canvas.coords(self.hint, w - 16, h - 12)

        if self._is_final() and not self.button_shown and alpha >= 1:
            self._show_final(w, h)

        self.root.after(33, self._tick)

    def _show_final(self, w, h):
        self.button_shown = True
        self.canvas.itemconfigure(self.hint, text="")
        pic = self.mascot or self.icon

        # Only draw the picture if there's room, so it never covers the text.
        if pic is not None and pic.height() <= h - 220:
            self.canvas.create_image(w / 2, h - 85, image=pic, anchor="s")

        self.btn = tk.Button(
            self.canvas, text=CLOSE_TEXT, command=self.close, relief="flat",
            cursor="hand2", bg="#ff4fa0", fg="#1a0710", activebackground="#ff7aa8",
            font=("Segoe UI", 11, "bold"), padx=18, pady=8, bd=0,
        )
        self.canvas.create_window(w / 2, h - 50, window=self.btn)

    def close(self, _event=None):
        if not self.alive:
            return

        self.alive = False

        for seq, funcid in self._binds:
            try:
                self.root.unbind(seq, funcid)
            except tk.TclError:
                pass

        try:
            self.frame.destroy()
        except tk.TclError:
            pass

        if self.on_close:
            self.on_close()
