@echo off
cd /d "%~dp0"
echo Installing PyInstaller (build tool only)...
python -m pip install pyinstaller
if errorlevel 1 (echo Could not install PyInstaller & pause & exit /b 1)
python -m PyInstaller --noconfirm --onefile --windowed --name ConeMacro --icon assets\icon.ico --add-data "assets;assets" main.py
if errorlevel 1 (echo Build failed & pause & exit /b 1)
echo.
echo Done! Your app is dist\ConeMacro.exe
pause
