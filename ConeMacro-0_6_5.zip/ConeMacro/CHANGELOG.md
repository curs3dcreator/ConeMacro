## UI refresh

- Reworked the Stats page into a grouped biome dashboard with rare/special spotlight cards, lifetime totals, session counts, and visual count bars.
- Updated the default Midnight palette to a warmer charcoal-and-amber theme and unified panel borders across the interface.

# ConeMacro Update Log

## 0.6.4
**Fixed**
- Custom alert sound rewritten to be much sturdier: files are played to completion with a proper path, and if the normal WAV player fails it falls back to Windows' media engine (which also handles MP3 and unusual WAVs).
- You can now pick MP3 (and WMA/M4A/AAC) as well as WAV.
- Choosing a sound plays it immediately, and the status bar shows whether it worked or the exact reason it didn't. "Preview" and "Test sound" report the same way.

## 0.6.3
- Minor fixes.

## 0.6.2
**New**
- Every biome from the Sol's RNG wiki (Eon 1-30) is now in the table, so none show up as "unknown" anymore. Added: Lost Forest, The Radiant Forest, Blood Rain, Eggland, Incinerator, Limbo, and the developer biomes.
- New **Dev** tier for developer / admin-abuse biomes: The Hyperspace Realm (+ Abnormality), The Null's Existence, The Citadel of Orders, The Red Full Moon, plus The Forgotten and Overture. It has its own colour, alert sound, Discord label, and its own Webhook / @Ping / Sound row in Settings (all on by default).
- Alternate names are recognised too (e.g. Edict, Mastermind, Another Realm), including the Japanese Red Full Moon name.

**Changed**
- The Radiant Forest is a **Rare** tier biome. Lost Forest is Common.
- The Citadel of Orders moved from Special to Dev.
- Dev biomes use your custom rare sound, like Rare and Special.
- Blazing Sun was listed twice, so I removed the duplicate.

## 0.6.1
**New**
- Start/Stop hotkey (default **F5**). It works globally, so it still fires while Roblox has focus. Change it in Settings: click the key button, then press the combo you want (Esc cancels). Clear turns it off, Reset puts F5 back. The Start/Stop button shows the current key, e.g. "Start  (F5)".
- Hotkeys can use Ctrl / Alt / Shift. Plain typing keys (A, 5, Space...) are refused unless combined with a modifier, so the hotkey can't fire while you type.
- The hotkey doesn't swallow the key, so other programs still receive it too.

## 0.5.9
**Fixed**
- Anti-AFK no longer knocks Roblox, or the window you return to, out of fullscreen/maximized. It used to "restore" every window it touched; now it only restores a window that is actually minimized (and re-minimizes it afterward).
- Anti-AFK now switches windows with a proper focus handoff instead of tapping Alt (Alt stays as a fallback only), waits until Roblox really has focus before pressing Space, and sends Space with its scan code.

## 0.5.8
**New**
- "Since last rare" is saved between launches (`state.json`) and rebuilt from `history.jsonl` on the first launch after updating.
- New cone app icon (`icon.ico` / `icon.png`, transparent background), also used in the header and the Windows taskbar.
- Mascot and background images auto-scale to fit. The background re-fits as the window is resized. JPG, BMP and WebP are accepted when Pillow is installed.
- Every tab scrolls when the window is small, so nothing overlaps. The scrollbar only shows when needed, and tables keep their own scrolling.

**Fixed**
- Custom rare sound: Special biomes (Singularity, Citadel of Orders) now use it too.
- Custom rare sound: unsupported WAV files (float, ADPCM, renamed MP3) now give a clear error instead of silently playing Windows' default sound or the built-in beep.

**UI**
- Hover highlights on buttons and sidebar items, focus rings on text boxes, themed scrollbars.
- Settings: added a title, roomier fields, and aligned the Webhook / @Ping / Sound columns.
- Smaller minimum window size, updated help text.

**Build**
- Pillow added to `requirements.txt`, `build_exe.bat`, the GitHub workflow, and `run.bat`. It is optional; without it images scale only in whole-number steps.
- Added tests for the saved counter and WAV validation.

## 0.5.7
- Starting point you uploaded.
