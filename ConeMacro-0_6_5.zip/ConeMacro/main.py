import sys
import tkinter as tk

from cone.gui import App


def main():
    if sys.platform == "win32":
        try:
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)  # crisp text on high-DPI screens
        except Exception:
            pass
        try:
            # Own taskbar identity so the cone icon shows instead of Python's.
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("ConeMacro.App")
        except Exception:
            pass
    root = tk.Tk()
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
