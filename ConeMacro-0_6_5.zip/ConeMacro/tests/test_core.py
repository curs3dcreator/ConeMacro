import json, os, sys, time, tempfile
from pathlib import Path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from cone import biomes, logwatch, webhook
from cone.store import History, Settings

def rpc(name):
    blob = {"command": "SetRichPresence", "data": {"largeImage": {"hoverText": name}}}
    return "2026-11-18T10:00:00.000Z,1.0,abc,6 [BloxstrapRPC] " + json.dumps(blob) + "\n"

def test_parse():
    assert logwatch.parse_line(rpc("GLITCHED")) == "GLITCHED"
    assert logwatch.parse_line("random line") is None

def test_lookup():
    assert biomes.lookup("GLITCHED").tier == "rare"
    assert biomes.lookup("The Citadel of Orders").tier == "dev"
    assert biomes.lookup("Brand New Biome").tier == "unknown"

def test_watcher():
    d = tempfile.mkdtemp()
    log = os.path.join(d, "a_Player_last.log")
    open(log, "w").write(rpc("NORMAL"))
    got = []
    w = logwatch.LogWatcher(lambda l, r, s: got.append((l, r, s)), lambda: d, poll=0.1)
    w.start(); time.sleep(0.6)
    with open(log, "a") as fh:
        fh.write(rpc("WINDY")); fh.write(rpc("WINDY")); fh.write(rpc("GLITCHED"))
    time.sleep(0.6); w.stop()
    assert got[0] == ("Roblox #1", "NORMAL", True), got
    assert [g[1] for g in got[1:]] == ["WINDY", "GLITCHED"], got
    assert all(g[2] is False for g in got[1:])

def test_history_and_payload():
    d = tempfile.mkdtemp()
    from pathlib import Path
    h = History(Path(d))
    h.add("Roblox #1", biomes.lookup("WINDY")); h.add("Roblox #1", biomes.lookup("GLITCHED"))
    assert h.since_rare == 0 and h.session_counts() == {"windy": 1, "glitched": 1}
    assert History(Path(d)).lifetime_counts()["glitched"] == 1
    p = webhook.biome_payload(biomes.lookup("GLITCHED"), "Roblox #1", "<@1>", True, 1, 0)
    assert p["content"] == "<@1>" and "RARE" in p["embeds"][0]["title"]
    s = Settings(Path(d)); s["mention"] = "x"; s.save(); assert Settings(Path(d))["mention"] == "x"


def test_parse_rpc_variants_and_escaped_text():
    assert logwatch.parse_line(rpc("DREAMSPACE").strip()) == "DREAMSPACE"
    alternate = '[BloxstrapRPC] {"command":"SetRichPresence","data":{"hoverText":"Blazing Sun"}}'
    assert logwatch.parse_line(alternate) == "Blazing Sun"
    assert logwatch.parse_line('[BloxstrapRPC] {"data":{"largeImage":{"hoverText":"The Citadel of Orders"}}}') == "The Citadel of Orders"
    assert logwatch.parse_line('[BloxstrapRPC] {"data":{"largeImage":{"hoverText":"A \\"quoted\\" biome"}}}') == 'A "quoted" biome'
    assert biomes.lookup("Blazing Sun").tier == "event"
    assert biomes.lookup("Glitched Biome").tier == "rare"


def test_biome_payload_includes_private_server_button_and_account():
    b = biomes.lookup("GLITCHED")
    link = "https://www.roblox.com/share?code=example&type=Server"
    payload = webhook.biome_payload(
        b, "Roblox #1", account_name="Curs3d", private_server_link=link
    )
    fields = payload["embeds"][0]["fields"]
    assert any(f["name"] == "Account" and f["value"] == "Curs3d" for f in fields)
    button = payload["components"][0]["components"][0]
    assert button["label"] == "Join Private Server"
    assert button["url"] == link and button["style"] == 5


def test_settings_migrates_legacy_account_and_supports_multiple_profiles():
    from pathlib import Path
    d = Path(tempfile.mkdtemp())
    (d / "settings.json").write_text(json.dumps({
        "account_name": "OldAccount",
        "private_server_link": "https://www.roblox.com/share?code=old&type=Server"
    }), "utf-8")
    settings = Settings(d)
    assert len(settings["accounts"]) == 1
    assert settings["accounts"][0]["name"] == "OldAccount"
    settings["accounts"].append({"id": "two", "name": "Second", "private_server_link": "https://www.roblox.com/share?code=two&type=Server"})
    settings["instance_accounts"] = {"Roblox #2": "two"}
    settings.save()
    loaded = Settings(d)
    assert [a["name"] for a in loaded["accounts"]] == ["OldAccount", "Second"]
    assert loaded["instance_accounts"]["Roblox #2"] == "two"


def test_engine_routes_instance_to_matching_account(monkeypatch):
    from cone.engine import Engine
    from cone.store import Settings, History
    from pathlib import Path
    d = Path(tempfile.mkdtemp())
    settings = Settings(d)
    settings["accounts"] = [
        {"id": "a", "name": "First", "private_server_link": "https://www.roblox.com/share?code=a&type=Server"},
        {"id": "b", "name": "Second", "private_server_link": "https://www.roblox.com/share?code=b&type=Server"},
    ]
    settings["instance_accounts"] = {"Roblox #2": "b"}
    engine = Engine(settings, History(d))
    assert engine._account_for_instance("Roblox #2")["name"] == "Second"
    assert engine._account_for_instance("Roblox #1") is None


def test_empty_account_list_does_not_restore_removed_legacy_account():
    from pathlib import Path
    d = Path(tempfile.mkdtemp())
    (d / "settings.json").write_text(json.dumps({
        "account_name": "OldAccount", "accounts": []
    }), "utf-8")
    assert Settings(d)["accounts"] == []


def test_biome_alert_uses_instance_specific_account_and_join_link(monkeypatch):
    from pathlib import Path
    from cone.engine import Engine
    import cone.engine as engine_module
    d = Path(tempfile.mkdtemp())
    settings = Settings(d)
    settings["webhook_url"] = "https://discord.com/api/webhooks/test/test"
    settings["accounts"] = [
        {"id": "one", "name": "Alpha", "private_server_link": "https://www.roblox.com/share?code=alpha&type=Server"},
        {"id": "two", "name": "Beta", "private_server_link": "https://www.roblox.com/share?code=beta&type=Server"},
    ]
    settings["instance_accounts"] = {"Roblox #2": "two"}
    sent = []
    monkeypatch.setattr(engine_module.webhook, "send", lambda url, payload, *args: sent.append(payload))
    engine = Engine(settings, History(d))
    engine._on_biome("Roblox #2", "GLITCHED", False)
    assert sent
    fields = sent[0]["embeds"][0]["fields"]
    assert any(f["name"] == "Account" and f["value"] == "Beta" for f in fields)
    assert sent[0]["components"][0]["components"][0]["url"].endswith("code=beta&type=Server")


def test_multi_macro_mode_watches_multiple_logs_and_single_mode_limits_to_one():
    import tempfile, os, time
    from cone.logwatch import LogWatcher
    d = tempfile.mkdtemp()
    for name, biome in (("a.log", "WINDY"), ("b.log", "GLITCHED")):
        with open(os.path.join(d, name), "w", encoding="utf-8") as fh:
            fh.write(rpc(biome))
    got_multi = []
    watcher = LogWatcher(lambda *args: got_multi.append(args), lambda: d,
                         poll=0.05, multi_macro_fn=lambda: True)
    watcher.start(); time.sleep(0.25); watcher.stop(); watcher.join(timeout=1)
    assert len(got_multi) == 2, got_multi

    got_single = []
    watcher = LogWatcher(lambda *args: got_single.append(args), lambda: d,
                         poll=0.05, multi_macro_fn=lambda: False)
    watcher.start(); time.sleep(0.25); watcher.stop(); watcher.join(timeout=1)
    assert len(got_single) == 1, got_single


def test_multi_macro_reuses_primary_account_for_unassigned_instances():
    from pathlib import Path
    from cone.engine import Engine
    from cone.store import Settings, History
    d = Path(tempfile.mkdtemp())
    settings = Settings(d)
    settings["accounts"] = [
        {"id": "primary", "name": "MainAccount", "private_server_link": "https://www.roblox.com/share?code=main&type=Server"},
        {"id": "other", "name": "OtherAccount", "private_server_link": "https://www.roblox.com/share?code=other&type=Server"},
    ]
    settings["multi_macro_enabled"] = True
    engine = Engine(settings, History(d))
    assert engine._account_for_instance("Roblox #3")["name"] == "MainAccount"
    settings["instance_accounts"] = {"Roblox #3": "other"}
    assert engine._account_for_instance("Roblox #3")["name"] == "OtherAccount"
    settings["multi_macro_enabled"] = False
    assert engine._account_for_instance("Roblox #4") is None


def test_single_macro_chooses_newest_active_log_and_skips_stale_first_file():
    import tempfile, os, time
    from cone.logwatch import LogWatcher, FRESH_SECONDS
    d = tempfile.mkdtemp()
    stale = os.path.join(d, "a_old.log")
    active = os.path.join(d, "z_current.log")
    with open(stale, "w", encoding="utf-8") as fh:
        fh.write(rpc("RAINY"))
    with open(active, "w", encoding="utf-8") as fh:
        fh.write(rpc("GLITCHED"))
    old = time.time() - FRESH_SECONDS - 120
    os.utime(stale, (old, old))
    got = []
    watcher = LogWatcher(lambda *args: got.append(args), lambda: d,
                         poll=0.05, multi_macro_fn=lambda: False)
    watcher.start()
    time.sleep(0.25)
    watcher.stop(); watcher.join(timeout=1)
    assert len(got) == 1, got
    assert got[0][1] == "GLITCHED", got


def test_single_macro_follows_most_recently_updated_instance():
    import tempfile, os, time
    from cone.logwatch import LogWatcher
    d = tempfile.mkdtemp()
    first = os.path.join(d, "a_first.log")
    second = os.path.join(d, "b_second.log")
    for path, biome in ((first, "WINDY"), (second, "GLITCHED")):
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(rpc(biome))
    now = time.time()
    os.utime(first, (now - 20, now - 20))
    os.utime(second, (now, now))
    got = []
    watcher = LogWatcher(lambda *args: got.append(args), lambda: d,
                         poll=0.05, multi_macro_fn=lambda: False)
    watcher.start(); time.sleep(0.25); watcher.stop(); watcher.join(timeout=1)
    assert len(got) == 1 and got[0][1] == "GLITCHED", got


def test_username_of_log_extracts_account_from_playergui_path():
    from cone.logwatch import username_of_log
    import tempfile, os
    path = os.path.join(tempfile.mkdtemp(), "client.log")
    with open(path, "w", encoding="utf-8") as fh:
        fh.write('Players.Curs3dCreator.PlayerGui:WaitForChild("TutorialCursor")\n')
    assert username_of_log(path) == "curs3dcreator"


def test_watcher_labels_log_with_matching_saved_account():
    import tempfile, os, time
    from cone.logwatch import LogWatcher
    d = tempfile.mkdtemp()
    path = os.path.join(d, "account.log")
    with open(path, "w", encoding="utf-8") as fh:
        fh.write('Players.Curs3dCreator.PlayerGui:WaitForChild("TutorialCursor")\n')
        fh.write(rpc("GLITCHED"))
    accounts = [{"id": "a", "name": "Curs3dCreator"}]
    got = []
    watcher = LogWatcher(lambda *args: got.append(args), lambda: d,
                         poll=0.05, multi_macro_fn=lambda: True,
                         accounts_fn=lambda: accounts)
    watcher.start(); time.sleep(0.25); watcher.stop(); watcher.join(timeout=1)
    assert got and got[0][0] == "Curs3dCreator", got


def test_engine_matches_detected_username_to_saved_account():
    from pathlib import Path
    from cone.engine import Engine
    from cone.store import Settings, History
    d = Path(tempfile.mkdtemp())
    settings = Settings(d)
    settings["accounts"] = [{"id": "acc", "name": "Curs3dCreator", "private_server_link": "https://example.com/server"}]
    engine = Engine(settings, History(d))
    assert engine._account_for_instance("curs3dcreator") == settings["accounts"][0]


def test_since_rare_persists_between_boots():
    import tempfile
    from pathlib import Path
    d = Path(tempfile.mkdtemp())
    h = History(d)
    h.add("Roblox #1", biomes.lookup("GLITCHED"))
    h.add("Roblox #1", biomes.lookup("WINDY"))
    h.add("Roblox #1", biomes.lookup("WINDY"))
    h2 = History(d)
    assert h2.since_rare == 2 and h2.last_rare_at is not None
    (d / "state.json").unlink()
    assert History(d).since_rare == 2  # rebuilt from history.jsonl


def test_check_wav():
    import struct, wave, tempfile, os
    from cone import sound
    d = tempfile.mkdtemp()
    good, bad = os.path.join(d, "a.wav"), os.path.join(d, "b.wav")
    with wave.open(good, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(8000)
        w.writeframes(struct.pack("<h", 0) * 800)
    open(bad, "wb").write(b"not a wav at all")
    assert sound.check_wav(good) is None
    assert sound.check_wav(bad) is not None
    assert sound.check_wav(os.path.join(d, "missing.wav")) is not None


def test_new_biomes_and_dev_tier():
    for raw, tier in [
        ("bloodrain", "event"),
        ("lostforest", "common"),
        ("theradiantforest", "rare"),
        ("Eggland", "event"),
        ("INCINERATOR", "event"),
        ("[ THE HYPERSPACE REALM ]", "dev"),
        ("THE NULL'S EXISTENCE", "dev"),
        ("The Citadel of Orders", "dev"),
        ("The Red Full Moon", "dev"),
    ]:
        assert biomes.lookup(raw).tier == tier, raw

    assert "dev" in biomes.TIERS
    assert Settings(Path(tempfile.mkdtemp())).get("webhook_tiers")["dev"]


def test_custom_sound_fallback_chain(monkeypatch=None):
    import os, struct, tempfile, time, wave
    from cone import sound

    d = tempfile.mkdtemp()
    good = os.path.join(d, "a.wav")
    with wave.open(good, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(8000)
        w.writeframes(struct.pack("<h", 0) * 800)
    mp3 = os.path.join(d, "b.mp3")
    open(mp3, "wb").write(b"ID3" + b"\0" * 64)

    assert sound.check_file(good) is None
    assert sound.check_file(mp3) is None
    assert sound.check_file(os.path.join(d, "c.ogg")) is not None

    sound.IS_WINDOWS = True
    calls = []
    real_ws, real_mci, real_beep = sound._winsound_play, sound._mci_play, sound._play_builtin
    try:
        # winsound fails -> MCI is used
        sound._winsound_play = lambda p: (calls.append("ws") or (False, "ws bad"))
        sound._mci_play = lambda p: (calls.append("mci") or (True, ""))
        assert sound._play_file(good) == (True, "")
        assert calls == ["ws", "mci"]

        # mp3 skips winsound entirely
        calls.clear()
        assert sound._play_file(mp3)[0] is True and calls == ["mci"]

        # everything fails -> reason reported, builtin beep fallback runs
        sound._mci_play = lambda p: (False, "MCI: nope")
        ok, msg = sound._play_file(good)
        assert not ok and "ws bad" in msg and "nope" in msg

        beeped, errs = [], []
        sound._play_builtin = lambda tier: beeped.append(tier)
        sound.play("rare", good, on_error=errs.append)
        time.sleep(0.3)
        assert beeped == ["rare"] and errs and "nope" in errs[0]
    finally:
        sound._winsound_play, sound._mci_play, sound._play_builtin = real_ws, real_mci, real_beep
        sound.IS_WINDOWS = sys.platform == "win32"
