# ConeMacro

A small, original biome logger for Sol's RNG. Written from scratch (Python + tkinter; Pillow is optional, for smooth image scaling).

**What it does**
- More tolerant Rich Presence parsing for biome changes (including alternate hoverText layouts)
- Improved live log tailing, partial-line handling, and log rotation detection
- Reads Roblox's log files live and notices every biome change (works with several Roblox windows at once)
- Discord webhook alerts with embeds, optional pings, per-tier on/off
- Alert sounds (no audio files needed)
- Dashboard: what biome each window is in, rough time left, session stats, "biomes since last rare"
- History + lifetime stats saved locally
- Anti-AFK (optional): taps Space in every Roblox window every N minutes
- Cone mascot who reacts to what you roll

## Get the app (no Python on your PC)
The .exe is built for you by GitHub's free cloud computers:
1. Make a free account at github.com and click **New repository** (private is fine). Name it anything.
2. Click **uploading an existing file** and drag in everything from this folder, including the `.github` folder. Commit.
3. Open the **Actions** tab -> **Build ConeMacro.exe** -> **Run workflow**. Wait about 2 minutes.
4. Click the finished run, download **ConeMacro-exe** at the bottom, unzip it. That's `ConeMacro.exe`.
5. Put it anywhere (Desktop is fine) and double-click. Right-click -> Send to -> Desktop for a shortcut.

Windows may say "Windows protected your PC" because the app isn't code-signed. Click **More info** -> **Run anyway**.

Then: open **Settings**, paste a Discord webhook URL if you want alerts, press **Save**, open Sol's RNG, press **Start**. The dashboard should show the current biome for each detected Roblox log.

## Running from source instead (needs Python 3.10+)
Double-click `run.bat`, or `python main.py`. `build_exe.bat` builds the exe locally.

## Where things are saved
`%LOCALAPPDATA%\ConeMacro\`  (paste that into File Explorer's address bar)
- `settings.json`  your settings (contains your webhook URL, don't share it)
- `history.jsonl`  every biome seen
- `state.json`  remembers your "since last rare" counter between launches

## Project layout
- `main.py` start here
- `cone/logwatch.py` reads the Roblox logs
- `cone/biomes.py` biome list (add new biomes here)
- `cone/engine.py` ties everything together
- `cone/gui.py` the window and mascot lines
- `cone/webhook.py`, `cone/sound.py`, `cone/antiafk.py`, `cone/store.py`
- `assets/` your images (mascot.png, icon.ico, avatar_small.png)
- `tests/` run with `python -m pytest`

## Notes
- If you use the Microsoft Store Roblox or a custom log folder, set it in Settings.
- Anti-AFK briefly brings Roblox to the front, so don't type while it fires.
- Automating a game can go against its rules. Use at your own risk.


## Discord biome alerts and multi-account profiles (v0.4.0)

1. Open **Settings**, paste your Discord webhook URL, choose which biome tiers should alert, and save.
2. Use **Test webhook** and wait for the delivery confirmation (or error message).
3. Open **Account** and add one profile for each Roblox account you already have running. Each profile can have its own private-server share link.
4. Press **Start**. ConeMacro discovers running Roblox log instances. In **Account → Instance Routing**, assign each detected instance to its matching account.
5. New biome alerts use the assigned account name and its **Join Private Server** button.

ConeMacro can monitor multiple Roblox instances at once and route each instance's biome alerts to a separate saved profile. It does not sign in, launch extra Roblox accounts, or bypass Roblox's account/session restrictions. The account manager stores only display names and private-server URLs; it does not ask for or store passwords or `.ROBLOSECURITY` cookies. Keep private-server links restricted to people you trust; anyone who receives one may be able to join, subject to Roblox server permissions.


## Multi-Macro Mode (0.5.1)

Open **Settings** and enable **Multi-Macro Mode**, then save and restart monitoring.
When disabled, ConeMacro watches only the most recently updated active Roblox log. When enabled, it watches every active Roblox log it can discover. In Multi-Macro Mode, ConeMacro checks every active Roblox log for its biome and attempts to identify the Roblox username from the log. If that username matches a saved account profile, the account and its private-server link are attached automatically. Enter each account using its exact Roblox username. If a username cannot be read or does not match a saved profile, use Account → Instance Routing to assign it manually. Unassigned instances use the first saved profile as a fallback; explicit assignments take priority.


## What's new in 0.5.9
- Anti-AFK no longer knocks Roblox (or the window you return to) out of fullscreen/maximized.

## Changes in 0.5.8
- "Since last rare" is saved and restored between launches.
- Custom rare sound: clearer errors for unsupported WAVs, and Special biomes use it too.
- New cone icon.
- Mascot and background images auto-scale to fit (the background re-fits as you resize the window).
- Every tab scrolls when the window is small. Cleaner buttons, nav hover, input focus rings and Settings layout.
